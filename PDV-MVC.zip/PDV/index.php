<?php
/**
 * FRONT CONTROLLER — único ponto de entrada da aplicação.
 * Rotas: index.php?r=<controller>/<acao>   ex.: index.php?r=clientes/editar&id=3
 */
require __DIR__ . '/app/bootstrap.php';

use App\Controllers\CarrinhoController;
use App\Controllers\ClienteController;
use App\Controllers\HomeController;
use App\Controllers\ProdutoController;
use App\Controllers\RelatorioController;
use App\Core\Container;
use App\Core\Database;
use App\Core\Env;
use App\Core\Router;
use App\Core\View;
use App\Repositories\Contracts\ClienteRepositoryInterface;
use App\Repositories\Contracts\ProdutoRepositoryInterface;
use App\Repositories\Contracts\VendaRepositoryInterface;
use App\Repositories\PdoClienteRepository;
use App\Repositories\PdoProdutoRepository;
use App\Repositories\PdoVendaRepository;

// ---- Injeção de dependências: interface -> implementação -------------------
$container = new Container();
$container->bind(PDO::class, fn() => Database::getInstance());   // Singleton
$container->bind(ClienteRepositoryInterface::class, fn(Container $c) => new PdoClienteRepository($c->get(PDO::class)));
$container->bind(ProdutoRepositoryInterface::class, fn(Container $c) => new PdoProdutoRepository($c->get(PDO::class)));
$container->bind(VendaRepositoryInterface::class,   fn(Container $c) => new PdoVendaRepository($c->get(PDO::class)));

// ---- Rotas ------------------------------------------------------------------
$router = (new Router($container))
    ->register('home',       HomeController::class)
    ->register('clientes',   ClienteController::class)
    ->register('produtos',   ProdutoController::class)
    ->register('carrinho',   CarrinhoController::class)
    ->register('relatorios', RelatorioController::class);

try {
    $router->dispatch();
} catch (Throwable $e) {
    error_log('[PDV] ' . get_class($e) . ': ' . $e->getMessage() . ' em ' . $e->getFile() . ':' . $e->getLine());
    while (ob_get_level() > 0) {
        ob_end_clean();
    }
    http_response_code(500);
    View::render('erros/500', [
        'titulo'  => 'Erro',
        'detalhe' => Env::get('APP_DEBUG') === '1' ? $e->getMessage() : null,
    ]);
}
