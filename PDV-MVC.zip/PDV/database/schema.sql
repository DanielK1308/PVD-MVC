-- =============================================================================
-- PDV — Schema PostgreSQL (Neon)
-- Pode ser executado várias vezes: usa CREATE ... IF NOT EXISTS.
-- Execute no SQL Editor do Neon.
-- =============================================================================

-- ---------------------------------------------------------------------------
-- PRODUTOS
-- Se a tabela já existe no seu banco, este comando não altera nada.
-- Colunas esperadas pelo sistema: id, cod, nome, categoria, validade,
-- quantidade, preco_unitario, preco_pacote, imagem.
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS produtos (
    id              SERIAL PRIMARY KEY,
    cod             VARCHAR(50)   NOT NULL,
    nome            VARCHAR(150)  NOT NULL,
    categoria       VARCHAR(100),
    validade        DATE,
    quantidade      INTEGER       NOT NULL DEFAULT 0 CHECK (quantidade >= 0),
    preco_unitario  NUMERIC(12,2) NOT NULL DEFAULT 0,
    preco_pacote    NUMERIC(12,2) NOT NULL DEFAULT 0,
    imagem          VARCHAR(255)
);

-- ---------------------------------------------------------------------------
-- CLIENTES  (tela 1)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS clientes (
    id             SERIAL PRIMARY KEY,
    nome           VARCHAR(150) NOT NULL,
    cpf_cnpj       VARCHAR(14)  UNIQUE,              -- somente dígitos
    email          VARCHAR(150),
    telefone       VARCHAR(20),
    cep            VARCHAR(8),
    endereco       VARCHAR(200),
    numero         VARCHAR(20),
    bairro         VARCHAR(100),
    cidade         VARCHAR(100),
    uf             CHAR(2),
    observacoes    TEXT,
    ativo          BOOLEAN      NOT NULL DEFAULT TRUE,
    criado_em      TIMESTAMPTZ  NOT NULL DEFAULT now(),
    atualizado_em  TIMESTAMPTZ  NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS idx_clientes_nome ON clientes (nome);

-- ---------------------------------------------------------------------------
-- VENDAS  (telas 2 e 3)
-- cliente_id NULL = consumidor final.
-- ON DELETE RESTRICT: cliente com vendas não pode ser apagado (use "inativo").
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS vendas (
    id               SERIAL PRIMARY KEY,
    cliente_id       INTEGER REFERENCES clientes (id) ON DELETE RESTRICT,
    subtotal         NUMERIC(12,2) NOT NULL DEFAULT 0,
    desconto_tipo    VARCHAR(10)   NOT NULL DEFAULT 'nenhum'
                     CHECK (desconto_tipo IN ('nenhum', 'percentual', 'valor')),
    desconto_valor   NUMERIC(12,2) NOT NULL DEFAULT 0,   -- o que foi digitado (% ou R$)
    desconto         NUMERIC(12,2) NOT NULL DEFAULT 0,   -- desconto calculado em R$
    total            NUMERIC(12,2) NOT NULL DEFAULT 0,
    forma_pagamento  VARCHAR(20)   NOT NULL DEFAULT 'dinheiro'
                     CHECK (forma_pagamento IN ('dinheiro', 'pix', 'cartao_debito', 'cartao_credito', 'fiado')),
    status           VARCHAR(10)   NOT NULL DEFAULT 'concluida'
                     CHECK (status IN ('concluida', 'cancelada')),
    observacoes      TEXT,
    criado_em        TIMESTAMPTZ   NOT NULL DEFAULT now(),
    cancelada_em     TIMESTAMPTZ
);
CREATE INDEX IF NOT EXISTS idx_vendas_criado_em ON vendas (criado_em);
CREATE INDEX IF NOT EXISTS idx_vendas_cliente   ON vendas (cliente_id);

-- ---------------------------------------------------------------------------
-- ITENS DA VENDA
-- Guarda cópia (snapshot) de código, nome e preço: o histórico não muda se o
-- produto for editado ou excluído depois (produto_id vira NULL ao excluir).
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS itens_venda (
    id              SERIAL PRIMARY KEY,
    venda_id        INTEGER       NOT NULL REFERENCES vendas (id) ON DELETE CASCADE,
    produto_id      INTEGER       REFERENCES produtos (id) ON DELETE SET NULL,
    produto_cod     VARCHAR(50)   NOT NULL,
    produto_nome    VARCHAR(150)  NOT NULL,
    quantidade      INTEGER       NOT NULL CHECK (quantidade > 0),
    preco_unitario  NUMERIC(12,2) NOT NULL,
    subtotal        NUMERIC(12,2) NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_itens_venda_venda   ON itens_venda (venda_id);
CREATE INDEX IF NOT EXISTS idx_itens_venda_produto ON itens_venda (produto_id);
