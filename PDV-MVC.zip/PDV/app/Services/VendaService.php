<?php
namespace App\Services;

use App\Models\FormaPagamento;
use App\Models\ItemVenda;
use App\Models\Venda;
use App\Repositories\Contracts\ClienteRepositoryInterface;
use App\Repositories\Contracts\ProdutoRepositoryInterface;
use App\Repositories\Contracts\VendaRepositoryInterface;
use App\Strategies\DescontoFactory;
use DomainException;
use PDO;
use Throwable;

/**
 * Service Layer: regras de negócio que envolvem várias tabelas.
 * Tudo roda em transação: ou grava a venda + baixa estoque, ou nada é gravado.
 */
final class VendaService
{
    public function __construct(
        private PDO $pdo,
        private VendaRepositoryInterface $vendas,
        private ProdutoRepositoryInterface $produtos,
        private ClienteRepositoryInterface $clientes
    ) {}

    /** CREATE: transforma o carrinho em venda. Retorna o id da venda. */
    public function finalizar(CarrinhoService $carrinho): int
    {
        $brutos = $carrinho->itensBrutos();
        if ($brutos === []) {
            throw new DomainException('O carrinho está vazio.');
        }
        $cfg = $carrinho->config();
        $this->validarCliente($cfg['cliente_id']);
        if (!FormaPagamento::valida($cfg['forma_pagamento'])) {
            throw new DomainException('Forma de pagamento inválida.');
        }

        return $this->transacao(function () use ($brutos, $cfg): int {
            $itens    = [];
            $subtotal = 0.0;

            foreach ($brutos as $produtoId => $qtd) {
                $produto = $this->produtos->lockForUpdate((int)$produtoId);
                if (!$produto) {
                    throw new DomainException("O produto #$produtoId não existe mais. Remova-o do carrinho.");
                }
                if ($produto->quantidade < $qtd) {
                    throw new DomainException(
                        "Estoque insuficiente para \"{$produto->nome}\" (disponível: {$produto->quantidade})."
                    );
                }
                $item      = ItemVenda::fromProduto($produto, (int)$qtd);
                $itens[]   = $item;
                $subtotal += $item->subtotal;
                $this->produtos->ajustarEstoque($produto->id, -((int)$qtd));
            }

            $subtotal = round($subtotal, 2);
            $desconto = DescontoFactory::criar($cfg['desconto_tipo'], (float)$cfg['desconto_valor']);

            $venda                  = new Venda();
            $venda->cliente_id      = $cfg['cliente_id'];
            $venda->subtotal        = $subtotal;
            $venda->desconto_tipo   = $desconto->tipo();
            $venda->desconto_valor  = $desconto->valor();
            $venda->desconto        = $desconto->calcular($subtotal);
            $venda->total           = round($subtotal - $venda->desconto, 2);
            $venda->forma_pagamento = $cfg['forma_pagamento'];
            $venda->status          = Venda::CONCLUIDA;
            $venda->observacoes     = $cfg['observacoes'] !== '' ? $cfg['observacoes'] : null;

            $vendaId = $this->vendas->inserir($venda);
            foreach ($itens as $item) {
                $item->venda_id = $vendaId;
                $this->vendas->inserirItem($item);
            }
            return $vendaId;
        });
    }

    /** UPDATE: altera apenas cliente, forma de pagamento e observações (itens/valores não mudam). */
    public function atualizar(int $id, ?int $clienteId, string $forma, ?string $obs): void
    {
        $venda = $this->vendas->find($id);
        if (!$venda) {
            throw new DomainException('Venda não encontrada.');
        }
        if (!$venda->concluida()) {
            throw new DomainException('Vendas canceladas não podem ser editadas.');
        }
        if (!FormaPagamento::valida($forma)) {
            throw new DomainException('Forma de pagamento inválida.');
        }
        if ($clienteId !== $venda->cliente_id) {   // manter um cliente já inativado é permitido
            $this->validarCliente($clienteId);
        }

        $this->vendas->atualizarDados($id, $clienteId, $forma, $obs);
    }

    /** Cancela a venda e devolve os itens ao estoque. */
    public function cancelar(int $id): void
    {
        $this->transacao(function () use ($id): void {
            $venda = $this->vendas->find($id);
            if (!$venda) {
                throw new DomainException('Venda não encontrada.');
            }
            if (!$this->vendas->marcarCancelada($id)) {
                throw new DomainException('Esta venda já está cancelada.');
            }
            $itens = $venda->itens;
            usort($itens, fn(ItemVenda $a, ItemVenda $b) => ($a->produto_id ?? 0) <=> ($b->produto_id ?? 0));
            foreach ($itens as $item) {
                if ($item->produto_id !== null) {   // produto pode ter sido excluído
                    $this->produtos->ajustarEstoque($item->produto_id, $item->quantidade);
                }
            }
        });
    }

    /** DELETE: só permitido para vendas já canceladas (preserva o histórico financeiro). */
    public function excluir(int $id): void
    {
        $venda = $this->vendas->find($id);
        if (!$venda) {
            throw new DomainException('Venda não encontrada.');
        }
        if ($venda->concluida()) {
            throw new DomainException('Cancele a venda antes de excluí-la.');
        }
        $this->vendas->delete($id);
    }

    private function validarCliente(?int $clienteId): void
    {
        if ($clienteId === null) {
            return;
        }
        $cliente = $this->clientes->find($clienteId);
        if (!$cliente) {
            throw new DomainException('Cliente não encontrado.');
        }
        if (!$cliente->ativo) {
            throw new DomainException('Este cliente está inativo.');
        }
    }

    /** Executa $fn em transação, com rollback em qualquer falha. */
    private function transacao(callable $fn): mixed
    {
        $this->pdo->beginTransaction();
        try {
            $resultado = $fn();
            $this->pdo->commit();
            return $resultado;
        } catch (Throwable $e) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }
            throw $e;
        }
    }
}
