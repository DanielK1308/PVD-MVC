<?php
namespace App\Services;

use App\Core\Session;
use App\Models\FormaPagamento;
use App\Models\ItemVenda;
use App\Repositories\Contracts\ProdutoRepositoryInterface;
use App\Strategies\DescontoFactory;
use DomainException;

/**
 * Service Layer: carrinho de vendas guardado na sessão.
 * Só guarda produto_id => quantidade; preços e estoque são sempre lidos do banco,
 * então o cliente nunca consegue alterar preço pelo navegador.
 */
final class CarrinhoService
{
    private const KEY = '_carrinho';

    public function __construct(private ProdutoRepositoryInterface $produtos) {}

    // ---------- CREATE / UPDATE / DELETE dos itens ----------

    public function adicionar(int $produtoId, int $quantidade): void
    {
        if ($quantidade < 1) {
            throw new DomainException('Informe uma quantidade maior que zero.');
        }
        $produto = $this->produtos->find($produtoId);
        if (!$produto) {
            throw new DomainException('Produto não encontrado.');
        }

        $estado = $this->estado();
        $nova   = ($estado['itens'][$produtoId] ?? 0) + $quantidade;
        if ($nova > $produto->quantidade) {
            throw new DomainException(
                "Estoque insuficiente para \"{$produto->nome}\" (disponível: {$produto->quantidade})."
            );
        }
        $estado['itens'][$produtoId] = $nova;
        $this->salvar($estado);
    }

    public function atualizar(int $produtoId, int $quantidade): void
    {
        if ($quantidade < 1) {
            $this->remover($produtoId);
            return;
        }
        $estado = $this->estado();
        if (!isset($estado['itens'][$produtoId])) {
            throw new DomainException('Item não está no carrinho.');
        }
        $produto = $this->produtos->find($produtoId);
        if (!$produto) {
            $this->remover($produtoId);
            throw new DomainException('Produto não existe mais e foi removido do carrinho.');
        }
        if ($quantidade > $produto->quantidade) {
            throw new DomainException(
                "Estoque insuficiente para \"{$produto->nome}\" (disponível: {$produto->quantidade})."
            );
        }
        $estado['itens'][$produtoId] = $quantidade;
        $this->salvar($estado);
    }

    public function remover(int $produtoId): void
    {
        $estado = $this->estado();
        unset($estado['itens'][$produtoId]);
        $this->salvar($estado);
    }

    public function limpar(): void
    {
        Session::forget(self::KEY);
    }

    // ---------- Configuração da venda (cliente, desconto, pagamento) ----------

    public function configurar(array $in): void
    {
        $estado = $this->estado();

        $cliente = (int)($in['cliente_id'] ?? 0);
        $estado['cliente_id'] = $cliente > 0 ? $cliente : null;

        $tipo = (string)($in['desconto_tipo'] ?? 'nenhum');
        $estado['desconto_tipo'] = in_array($tipo, ['nenhum', 'percentual', 'valor'], true) ? $tipo : 'nenhum';

        $valor = (float)str_replace(',', '.', (string)($in['desconto_valor'] ?? 0));
        $estado['desconto_valor'] = max(0.0, $valor);

        $forma = (string)($in['forma_pagamento'] ?? 'dinheiro');
        $estado['forma_pagamento'] = FormaPagamento::valida($forma) ? $forma : 'dinheiro';

        $obs = trim((string)($in['observacoes'] ?? ''));
        $estado['observacoes'] = mb_substr($obs, 0, 500);

        $this->salvar($estado);
    }

    public function config(): array
    {
        $e = $this->estado();
        unset($e['itens']);
        return $e;
    }

    // ---------- READ ----------

    /** @return array<int,int> produto_id => quantidade */
    public function itensBrutos(): array
    {
        $itens = $this->estado()['itens'];
        ksort($itens); // ordem estável (evita deadlock ao travar linhas)
        return $itens;
    }

    public function vazio(): bool
    {
        return $this->estado()['itens'] === [];
    }

    /** @return ItemVenda[] */
    public function itens(): array
    {
        $estado = $this->estado();
        $mapa   = $this->produtos->findMany(array_keys($estado['itens']));
        $itens  = [];
        $mudou  = false;

        foreach ($estado['itens'] as $id => $qtd) {
            if (!isset($mapa[$id])) {          // produto excluído: some do carrinho
                unset($estado['itens'][$id]);
                $mudou = true;
                continue;
            }
            $itens[] = ItemVenda::fromProduto($mapa[$id], (int)$qtd);
        }
        if ($mudou) {
            $this->salvar($estado);
        }
        return $itens;
    }

    /** @return array{itens: ItemVenda[], qtd_itens:int, subtotal:float, desconto:float, total:float} */
    public function resumo(): array
    {
        $itens    = $this->itens();
        $subtotal = round(array_sum(array_map(fn(ItemVenda $i) => $i->subtotal, $itens)), 2);
        $cfg      = $this->config();
        $desconto = DescontoFactory::criar($cfg['desconto_tipo'], (float)$cfg['desconto_valor'])->calcular($subtotal);

        return [
            'itens'     => $itens,
            'qtd_itens' => (int)array_sum(array_map(fn(ItemVenda $i) => $i->quantidade, $itens)),
            'subtotal'  => $subtotal,
            'desconto'  => $desconto,
            'total'     => round($subtotal - $desconto, 2),
        ];
    }

    // ---------- interno ----------

    private function estado(): array
    {
        return array_merge([
            'itens'           => [],
            'cliente_id'      => null,
            'desconto_tipo'   => 'nenhum',
            'desconto_valor'  => 0.0,
            'forma_pagamento' => 'dinheiro',
            'observacoes'     => '',
        ], Session::get(self::KEY, []));
    }

    private function salvar(array $estado): void
    {
        Session::set(self::KEY, $estado);
    }
}
