<?php
namespace App\Models;

final class Produto extends Entity
{
    public ?int $id = null;
    public string $cod = '';
    public string $nome = '';
    public ?string $categoria = null;
    public ?string $validade = null;
    public int $quantidade = 0;
    public float $preco_unitario = 0.0;
    public float $preco_pacote = 0.0;
    public ?string $imagem = null;

    public static function fromArray(array $d): static
    {
        $p = new static();
        $p->id             = self::intOrNull($d['id'] ?? null);
        $p->cod            = trim((string)($d['cod'] ?? ''));
        $p->nome           = trim((string)($d['nome'] ?? ''));
        $p->categoria      = self::nullable($d['categoria'] ?? null);
        $p->validade       = self::nullable($d['validade'] ?? null);
        $p->quantidade     = (int)($d['quantidade'] ?? 0);
        $p->preco_unitario = self::decimal($d['preco_unitario'] ?? 0);
        $p->preco_pacote   = self::decimal($d['preco_pacote'] ?? 0);
        $p->imagem         = self::nullable($d['imagem'] ?? null);
        return $p;
    }
}
