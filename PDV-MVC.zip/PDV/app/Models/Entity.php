<?php
namespace App\Models;

/** Base das entidades: conversões seguras de tipos vindos de formulário/banco. */
abstract class Entity
{
    protected static function nullable(mixed $v): ?string
    {
        if ($v === null) {
            return null;
        }
        $v = trim((string)$v);
        return $v === '' ? null : $v;
    }

    protected static function intOrNull(mixed $v): ?int
    {
        return ($v === null || $v === '') ? null : (int)$v;
    }

    protected static function decimal(mixed $v): float
    {
        if (is_string($v)) {
            $v = str_replace(',', '.', trim($v));
        }
        return (float)$v;
    }

    public function toArray(): array
    {
        return get_object_vars($this);
    }
}
