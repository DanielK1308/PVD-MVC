<?php
namespace App\Models;

final class Venda extends Entity
{
    public const CONCLUIDA = 'concluida';
    public const CANCELADA = 'cancelada';

    public ?int $id = null;
    public ?int $cliente_id = null;
    public ?string $cliente_nome = null;   // vem do JOIN com clientes
    public float $subtotal = 0.0;
    public string $desconto_tipo = 'nenhum';
    public float $desconto_valor = 0.0;
    public float $desconto = 0.0;          // desconto calculado em R$
    public float $total = 0.0;
    public string $forma_pagamento = 'dinheiro';
    public string $status = self::CONCLUIDA;
    public ?string $observacoes = null;
    public ?string $criado_em = null;
    public ?string $cancelada_em = null;
    /** @var ItemVenda[] */
    public array $itens = [];

    public static function fromArray(array $d): static
    {
        $v = new static();
        $v->id              = self::intOrNull($d['id'] ?? null);
        $v->cliente_id      = self::intOrNull($d['cliente_id'] ?? null);
        $v->cliente_nome    = self::nullable($d['cliente_nome'] ?? null);
        $v->subtotal        = self::decimal($d['subtotal'] ?? 0);
        $v->desconto_tipo   = (string)($d['desconto_tipo'] ?? 'nenhum');
        $v->desconto_valor  = self::decimal($d['desconto_valor'] ?? 0);
        $v->desconto        = self::decimal($d['desconto'] ?? 0);
        $v->total           = self::decimal($d['total'] ?? 0);
        $v->forma_pagamento = (string)($d['forma_pagamento'] ?? 'dinheiro');
        $v->status          = (string)($d['status'] ?? self::CONCLUIDA);
        $v->observacoes     = self::nullable($d['observacoes'] ?? null);
        $v->criado_em       = self::nullable($d['criado_em'] ?? null);
        $v->cancelada_em    = self::nullable($d['cancelada_em'] ?? null);
        return $v;
    }

    public function concluida(): bool
    {
        return $this->status === self::CONCLUIDA;
    }
}
