<?php
namespace App\Models;

final class FormaPagamento
{
    public const LISTA = [
        'dinheiro'        => 'Dinheiro',
        'pix'             => 'PIX',
        'cartao_debito'   => 'Cartão de débito',
        'cartao_credito'  => 'Cartão de crédito',
        'fiado'           => 'Fiado',
    ];

    public static function valida(string $codigo): bool
    {
        return isset(self::LISTA[$codigo]);
    }

    public static function rotulo(?string $codigo): string
    {
        return self::LISTA[$codigo ?? ''] ?? (string)$codigo;
    }
}
