<?php
namespace App\Models;

final class Cliente extends Entity
{
    public ?int $id = null;
    public string $nome = '';
    public ?string $cpf_cnpj = null;   // somente dígitos
    public ?string $email = null;
    public ?string $telefone = null;
    public ?string $cep = null;
    public ?string $endereco = null;
    public ?string $numero = null;
    public ?string $bairro = null;
    public ?string $cidade = null;
    public ?string $uf = null;
    public ?string $observacoes = null;
    public bool $ativo = true;
    public ?string $criado_em = null;

    /** Aceita tanto a linha do banco quanto o $_POST do formulário. */
    public static function fromArray(array $d): static
    {
        $c = new static();
        $c->id          = self::intOrNull($d['id'] ?? null);
        $c->nome        = trim((string)($d['nome'] ?? ''));
        $doc            = preg_replace('/\D/', '', (string)($d['cpf_cnpj'] ?? ''));
        $c->cpf_cnpj    = $doc === '' ? null : $doc;
        $c->email       = self::nullable($d['email'] ?? null);
        $c->telefone    = self::nullable($d['telefone'] ?? null);
        $cep            = preg_replace('/\D/', '', (string)($d['cep'] ?? ''));
        $c->cep         = $cep === '' ? null : $cep;
        $c->endereco    = self::nullable($d['endereco'] ?? null);
        $c->numero      = self::nullable($d['numero'] ?? null);
        $c->bairro      = self::nullable($d['bairro'] ?? null);
        $c->cidade      = self::nullable($d['cidade'] ?? null);
        $uf             = self::nullable($d['uf'] ?? null);
        $c->uf          = $uf === null ? null : strtoupper($uf);
        $c->observacoes = self::nullable($d['observacoes'] ?? null);
        $c->ativo       = filter_var($d['ativo'] ?? false, FILTER_VALIDATE_BOOLEAN);
        $c->criado_em   = self::nullable($d['criado_em'] ?? null);
        return $c;
    }
}
