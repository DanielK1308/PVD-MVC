<?php
namespace App\Models;

/** Item de venda (também usado como linha do carrinho). */
final class ItemVenda extends Entity
{
    public ?int $id = null;
    public ?int $venda_id = null;
    public ?int $produto_id = null;
    public string $produto_cod = '';
    public string $produto_nome = '';
    public int $quantidade = 0;
    public float $preco_unitario = 0.0;
    public float $subtotal = 0.0;
    // Apenas para exibição no carrinho (não persistidos):
    public ?string $imagem = null;
    public int $estoque = 0;

    public static function fromArray(array $d): static
    {
        $i = new static();
        $i->id             = self::intOrNull($d['id'] ?? null);
        $i->venda_id       = self::intOrNull($d['venda_id'] ?? null);
        $i->produto_id     = self::intOrNull($d['produto_id'] ?? null);
        $i->produto_cod    = (string)($d['produto_cod'] ?? '');
        $i->produto_nome   = (string)($d['produto_nome'] ?? '');
        $i->quantidade     = (int)($d['quantidade'] ?? 0);
        $i->preco_unitario = self::decimal($d['preco_unitario'] ?? 0);
        $i->subtotal       = self::decimal($d['subtotal'] ?? 0);
        return $i;
    }

    public static function fromProduto(Produto $p, int $quantidade): static
    {
        $i = new static();
        $i->produto_id     = $p->id;
        $i->produto_cod    = $p->cod;
        $i->produto_nome   = $p->nome;
        $i->quantidade     = $quantidade;
        $i->preco_unitario = $p->preco_unitario;
        $i->subtotal       = round($quantidade * $p->preco_unitario, 2);
        $i->imagem         = $p->imagem;
        $i->estoque        = $p->quantidade;
        return $i;
    }
}
