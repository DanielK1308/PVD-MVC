<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Validator;
use App\Models\Produto;
use App\Repositories\Contracts\ProdutoRepositoryInterface;
use DomainException;

/** CRUD de produtos (migração do cadastro/edição/exclusão que existiam soltos). */
final class ProdutoController extends Controller
{
    private const POR_PAGINA = 15;

    public function __construct(private ProdutoRepositoryInterface $produtos) {}

    public function indexAction(): void
    {
        $q    = trim((string)($_GET['q'] ?? ''));
        $page = $this->page();
        $res  = $this->produtos->paginate($q, $page, self::POR_PAGINA);

        $this->view('produtos/index', [
            'titulo'   => 'Produtos',
            'produtos' => $res['items'],
            'total'    => $res['total'],
            'q'        => $q,
            'page'     => $page,
            'perPage'  => self::POR_PAGINA,
        ]);
    }

    public function novoAction(): void
    {
        $this->formulario(new Produto(), []);
    }

    public function salvarAction(): void
    {
        $this->requirePost();
        $produto     = Produto::fromArray($_POST);
        $produto->id = null;
        $errors      = $this->validar($produto);

        if (!$errors) {
            try {
                $produto->imagem = $this->uploadImagem();
            } catch (DomainException $e) {
                $errors['imagem'] = $e->getMessage();
            }
        }
        if ($errors) {
            $this->formulario($produto, $errors);
            return;
        }
        $this->produtos->save($produto);
        $this->flash('success', 'Produto cadastrado com sucesso!');
        $this->redirect('produtos/index');
    }

    public function editarAction(): void
    {
        $produto = $this->produtos->find($this->idGet());
        if (!$produto) {
            $this->flash('danger', 'Produto não encontrado.');
            $this->redirect('produtos/index');
        }
        $this->formulario($produto, []);
    }

    public function atualizarAction(): void
    {
        $this->requirePost();
        $id        = $this->idPost();
        $existente = $this->produtos->find($id);
        if (!$existente) {
            $this->flash('danger', 'Produto não encontrado.');
            $this->redirect('produtos/index');
        }

        $produto         = Produto::fromArray($_POST);
        $produto->id     = $id;
        $produto->imagem = $existente->imagem;   // mantém a imagem atual se nenhuma nova for enviada
        $errors          = $this->validar($produto);

        if (!$errors) {
            try {
                $nova = $this->uploadImagem();
                if ($nova !== null) {
                    $produto->imagem = $nova;
                }
            } catch (DomainException $e) {
                $errors['imagem'] = $e->getMessage();
            }
        }
        if ($errors) {
            $this->formulario($produto, $errors);
            return;
        }
        $this->produtos->save($produto);
        $this->flash('success', 'Produto atualizado com sucesso!');
        $this->redirect('produtos/index');
    }

    public function excluirAction(): void
    {
        $this->requirePost();
        $ok = $this->produtos->delete($this->idPost());
        $this->flash($ok ? 'success' : 'warning', $ok ? 'Produto excluído.' : 'Produto não encontrado.');
        $this->redirect('produtos/index');
    }

    // ------------------------------------------------------------------

    private function formulario(Produto $produto, array $errors): void
    {
        $this->view('produtos/form', [
            'titulo'  => $produto->id ? 'Editar produto' : 'Novo produto',
            'produto' => $produto,
            'errors'  => $errors,
        ]);
    }

    private function validar(Produto $p): array
    {
        $v = (new Validator())
            ->required('cod', $p->cod, 'Código')
            ->maxLength('cod', $p->cod, 50, 'Código')
            ->required('nome', $p->nome, 'Nome')
            ->maxLength('nome', $p->nome, 150, 'Nome')
            ->maxLength('categoria', $p->categoria, 100, 'Categoria')
            ->min('quantidade', $p->quantidade, 0, 'Quantidade')
            ->min('preco_unitario', $p->preco_unitario, 0, 'Preço unitário')
            ->min('preco_pacote', $p->preco_pacote, 0, 'Preço do pacote');

        if ($p->validade !== null && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $p->validade)) {
            $v->addError('validade', 'Data de validade inválida.');
        }
        if ($p->cod !== '' && !isset($v->errors()['cod']) && $this->produtos->findByCod($p->cod, $p->id)) {
            $v->addError('cod', 'Já existe um produto com este código.');
        }
        return $v->errors();
    }

    /** Valida e move o upload. Retorna o nome do arquivo ou null se nada foi enviado. */
    private function uploadImagem(): ?string
    {
        $file = $_FILES['imagem'] ?? null;
        if ($file === null || $file['error'] === UPLOAD_ERR_NO_FILE) {
            return null;
        }
        if ($file['error'] !== UPLOAD_ERR_OK) {
            throw new DomainException('Falha no envio da imagem.');
        }
        if ($file['size'] > 2 * 1024 * 1024) {
            throw new DomainException('A imagem deve ter no máximo 2 MB.');
        }
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif', 'webp'], true) || @getimagesize($file['tmp_name']) === false) {
            throw new DomainException('Envie uma imagem válida (JPG, PNG, GIF ou WEBP).');
        }
        $nome = bin2hex(random_bytes(8)) . '.' . $ext;
        if (!move_uploaded_file($file['tmp_name'], BASE_PATH . '/imagens/' . $nome)) {
            throw new DomainException('Não foi possível salvar a imagem na pasta imagens/.');
        }
        return $nome;
    }
}
