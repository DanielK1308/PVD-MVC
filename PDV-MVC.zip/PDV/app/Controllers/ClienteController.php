<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Core\Validator;
use App\Models\Cliente;
use App\Repositories\Contracts\ClienteRepositoryInterface;
use PDOException;

/** CRUD de clientes. */
final class ClienteController extends Controller
{
    private const POR_PAGINA = 15;

    public function __construct(private ClienteRepositoryInterface $clientes) {}

    /** READ (lista + busca) */
    public function indexAction(): void
    {
        $q    = trim((string)($_GET['q'] ?? ''));
        $page = $this->page();
        $res  = $this->clientes->paginate($q, $page, self::POR_PAGINA);

        $this->view('clientes/index', [
            'titulo'  => 'Clientes',
            'clientes' => $res['items'],
            'total'   => $res['total'],
            'q'       => $q,
            'page'    => $page,
            'perPage' => self::POR_PAGINA,
        ]);
    }

    /** CREATE (formulário) */
    public function novoAction(): void
    {
        $this->formulario(new Cliente(), []);
    }

    /** CREATE (grava) */
    public function salvarAction(): void
    {
        $this->requirePost();
        $cliente     = Cliente::fromArray($_POST);
        $cliente->id = null;

        $errors = $this->validar($cliente);
        if ($errors) {
            $this->formulario($cliente, $errors);
            return;
        }
        $this->clientes->save($cliente);
        $this->flash('success', 'Cliente cadastrado com sucesso!');
        $this->redirect('clientes/index');
    }

    /** UPDATE (formulário) */
    public function editarAction(): void
    {
        $cliente = $this->clientes->find($this->idGet());
        if (!$cliente) {
            $this->flash('danger', 'Cliente não encontrado.');
            $this->redirect('clientes/index');
        }
        $this->formulario($cliente, []);
    }

    /** UPDATE (grava) */
    public function atualizarAction(): void
    {
        $this->requirePost();
        $id        = $this->idPost();
        $existente = $this->clientes->find($id);
        if (!$existente) {
            $this->flash('danger', 'Cliente não encontrado.');
            $this->redirect('clientes/index');
        }

        $cliente            = Cliente::fromArray($_POST);
        $cliente->id        = $id;
        $cliente->criado_em = $existente->criado_em;

        $errors = $this->validar($cliente);
        if ($errors) {
            $this->formulario($cliente, $errors);
            return;
        }
        $this->clientes->save($cliente);
        $this->flash('success', 'Cliente atualizado com sucesso!');
        $this->redirect('clientes/index');
    }

    /** DELETE */
    public function excluirAction(): void
    {
        $this->requirePost();
        try {
            $ok = $this->clientes->delete($this->idPost());
            $this->flash($ok ? 'success' : 'warning', $ok ? 'Cliente excluído.' : 'Cliente não encontrado.');
        } catch (PDOException $e) {
            if ($e->getCode() === '23503') { // violação de chave estrangeira
                $this->flash('warning', 'Este cliente possui vendas e não pode ser excluído. Edite o cadastro e desmarque "Ativo" para inativá-lo.');
            } else {
                throw $e;
            }
        }
        $this->redirect('clientes/index');
    }

    // ------------------------------------------------------------------

    private function formulario(Cliente $cliente, array $errors): void
    {
        $this->view('clientes/form', [
            'titulo'  => $cliente->id ? 'Editar cliente' : 'Novo cliente',
            'cliente' => $cliente,
            'errors'  => $errors,
        ]);
    }

    private function validar(Cliente $c): array
    {
        $v = (new Validator())
            ->required('nome', $c->nome, 'Nome')
            ->maxLength('nome', $c->nome, 150, 'Nome')
            ->email('email', $c->email)
            ->maxLength('email', $c->email, 150, 'E-mail')
            ->documento('cpf_cnpj', $c->cpf_cnpj)
            ->maxLength('telefone', $c->telefone, 20, 'Telefone')
            ->maxLength('endereco', $c->endereco, 200, 'Endereço')
            ->maxLength('numero', $c->numero, 20, 'Número')
            ->maxLength('bairro', $c->bairro, 100, 'Bairro')
            ->maxLength('cidade', $c->cidade, 100, 'Cidade')
            ->uf('uf', $c->uf);

        if ($c->cep !== null && strlen($c->cep) !== 8) {
            $v->addError('cep', 'CEP deve ter 8 dígitos.');
        }

        if ($c->cpf_cnpj !== null && !isset($v->errors()['cpf_cnpj'])
            && $this->clientes->findByDocumento($c->cpf_cnpj, $c->id)) {
            $v->addError('cpf_cnpj', 'Já existe um cliente com este CPF/CNPJ.');
        }
        return $v->errors();
    }
}
