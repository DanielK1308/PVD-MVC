<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Repositories\Contracts\ClienteRepositoryInterface;
use App\Repositories\Contracts\ProdutoRepositoryInterface;
use App\Services\CarrinhoService;
use App\Services\VendaService;
use DomainException;

/** CRUD do carrinho de vendas: adicionar, listar, alterar quantidade, remover, finalizar. */
final class CarrinhoController extends Controller
{
    public function __construct(
        private CarrinhoService $carrinho,
        private VendaService $vendas,
        private ProdutoRepositoryInterface $produtos,
        private ClienteRepositoryInterface $clientes
    ) {}

    /** READ */
    public function indexAction(): void
    {
        $q = trim((string)($_GET['q'] ?? ''));
        $this->view('carrinho/index', [
            'titulo'   => 'Carrinho de vendas',
            'q'        => $q,
            'produtos' => $this->produtos->buscarParaVenda($q),
            'resumo'   => $this->carrinho->resumo(),
            'config'   => $this->carrinho->config(),
            'clientes' => $this->clientes->ativos(),
        ]);
    }

    /** CREATE (item) */
    public function adicionarAction(): void
    {
        $this->requirePost();
        $this->tentar(fn() => $this->carrinho->adicionar($this->idPost('produto_id'), (int)($_POST['quantidade'] ?? 1)),
            'Item adicionado ao carrinho.');
        $this->voltar();
    }

    /** UPDATE (quantidade) */
    public function atualizarAction(): void
    {
        $this->requirePost();
        $this->tentar(fn() => $this->carrinho->atualizar($this->idPost('produto_id'), (int)($_POST['quantidade'] ?? 0)),
            'Quantidade atualizada.');
        $this->voltar();
    }

    /** DELETE (item) */
    public function removerAction(): void
    {
        $this->requirePost();
        $this->carrinho->remover($this->idPost('produto_id'));
        $this->flash('success', 'Item removido do carrinho.');
        $this->voltar();
    }

    /** DELETE (carrinho inteiro) */
    public function limparAction(): void
    {
        $this->requirePost();
        $this->carrinho->limpar();
        $this->flash('success', 'Carrinho esvaziado.');
        $this->voltar();
    }

    /** UPDATE (cliente, desconto, pagamento) sem finalizar */
    public function resumoAction(): void
    {
        $this->requirePost();
        $this->carrinho->configurar($_POST);
        $this->flash('info', 'Resumo atualizado.');
        $this->voltar();
    }

    /** Finaliza: grava a venda, baixa o estoque e abre o comprovante. */
    public function finalizarAction(): void
    {
        $this->requirePost();
        $this->carrinho->configurar($_POST);

        try {
            $vendaId = $this->vendas->finalizar($this->carrinho);
        } catch (DomainException $e) {
            $this->flash('danger', $e->getMessage());
            $this->voltar();
            return;
        }
        $this->carrinho->limpar();
        $this->flash('success', "Venda #$vendaId finalizada com sucesso!");
        $this->redirect('relatorios/ver', ['id' => $vendaId]);
    }

    // ------------------------------------------------------------------

    private function tentar(callable $acao, string $sucesso): void
    {
        try {
            $acao();
            $this->flash('success', $sucesso);
        } catch (DomainException $e) {
            $this->flash('danger', $e->getMessage());
        }
    }

    /** Volta ao carrinho preservando a busca de produtos. */
    private function voltar(): void
    {
        $q = trim((string)($_POST['q'] ?? ''));
        $this->redirect('carrinho/index', $q !== '' ? ['q' => $q] : []);
    }
}
