<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Models\FormaPagamento;
use App\Models\Venda;
use App\Repositories\Contracts\ClienteRepositoryInterface;
use App\Repositories\Contracts\VendaRepositoryInterface;
use App\Services\VendaService;
use DomainException;

/** Relatórios de vendas + CRUD das vendas registradas. */
final class RelatorioController extends Controller
{
    private const POR_PAGINA = 15;

    public function __construct(
        private VendaRepositoryInterface $vendas,
        private VendaService $servico,
        private ClienteRepositoryInterface $clientes
    ) {}

    /** READ: filtros + indicadores + gráfico + lista paginada */
    public function indexAction(): void
    {
        $filtros = $this->filtros();
        $page    = $this->page();
        $res     = $this->vendas->paginate($filtros, $page, self::POR_PAGINA);

        $this->view('relatorios/index', [
            'titulo'    => 'Relatório de vendas',
            'filtros'   => $filtros,
            'vendas'    => $res['items'],
            'total'     => $res['total'],
            'page'      => $page,
            'perPage'   => self::POR_PAGINA,
            'totais'    => $this->vendas->totais($filtros),
            'topProdutos' => $this->vendas->topProdutos($filtros),
            'porDia'    => $this->vendas->porDia($filtros),
            'porForma'  => $this->vendas->porFormaPagamento($filtros),
            'clientes'  => $this->clientes->ativos(),
        ]);
    }

    /** READ: detalhe / comprovante */
    public function verAction(): void
    {
        $venda = $this->vendas->find($this->idGet());
        if (!$venda) {
            $this->flash('danger', 'Venda não encontrada.');
            $this->redirect('relatorios/index');
        }
        $this->view('relatorios/ver', ['titulo' => 'Venda #' . $venda->id, 'venda' => $venda]);
    }

    /** UPDATE (formulário) */
    public function editarAction(): void
    {
        $venda = $this->vendas->find($this->idGet());
        if (!$venda) {
            $this->flash('danger', 'Venda não encontrada.');
            $this->redirect('relatorios/index');
        }
        if (!$venda->concluida()) {
            $this->flash('warning', 'Vendas canceladas não podem ser editadas.');
            $this->redirect('relatorios/ver', ['id' => $venda->id]);
        }
        $this->view('relatorios/editar', [
            'titulo'   => 'Editar venda #' . $venda->id,
            'venda'    => $venda,
            'clientes' => $this->clientes->ativos(),
        ]);
    }

    /** UPDATE (grava) */
    public function atualizarAction(): void
    {
        $this->requirePost();
        $id      = $this->idPost();
        $cliente = (int)($_POST['cliente_id'] ?? 0);
        $obs     = trim((string)($_POST['observacoes'] ?? ''));

        try {
            $this->servico->atualizar(
                $id,
                $cliente > 0 ? $cliente : null,
                (string)($_POST['forma_pagamento'] ?? ''),
                $obs !== '' ? mb_substr($obs, 0, 500) : null
            );
            $this->flash('success', "Venda #$id atualizada.");
        } catch (DomainException $e) {
            $this->flash('danger', $e->getMessage());
        }
        $this->redirect('relatorios/ver', ['id' => $id]);
    }

    /** Cancela a venda (estorna o estoque). */
    public function cancelarAction(): void
    {
        $this->requirePost();
        $id = $this->idPost();
        try {
            $this->servico->cancelar($id);
            $this->flash('success', "Venda #$id cancelada e estoque devolvido.");
        } catch (DomainException $e) {
            $this->flash('danger', $e->getMessage());
        }
        $this->redirect('relatorios/index');
    }

    /** DELETE (somente vendas canceladas). */
    public function excluirAction(): void
    {
        $this->requirePost();
        $id = $this->idPost();
        try {
            $this->servico->excluir($id);
            $this->flash('success', "Venda #$id excluída.");
        } catch (DomainException $e) {
            $this->flash('danger', $e->getMessage());
        }
        $this->redirect('relatorios/index');
    }

    /** Exporta o relatório filtrado em CSV (abre direto no Excel pt-BR). */
    public function exportarAction(): void
    {
        $vendas = $this->vendas->listar($this->filtros());

        header('Content-Type: text/csv; charset=UTF-8');
        header('Content-Disposition: attachment; filename="vendas_' . date('Ymd_His') . '.csv"');

        $out = fopen('php://output', 'w');
        fwrite($out, "\xEF\xBB\xBF"); // BOM UTF-8
        fputcsv($out, ['Venda', 'Data', 'Cliente', 'Pagamento', 'Subtotal', 'Desconto', 'Total', 'Status'], ';');
        foreach ($vendas as $v) {
            fputcsv($out, [
                $v->id,
                data_br($v->criado_em, true),
                $this->csv($v->cliente_nome ?? 'Consumidor final'),
                FormaPagamento::rotulo($v->forma_pagamento),
                number_format($v->subtotal, 2, ',', ''),
                number_format($v->desconto, 2, ',', ''),
                number_format($v->total, 2, ',', ''),
                $v->status === Venda::CONCLUIDA ? 'Concluída' : 'Cancelada',
            ], ';');
        }
        fclose($out);
        exit;
    }

    // ------------------------------------------------------------------

    /** Lê e sanitiza os filtros da query string. */
    private function filtros(): array
    {
        $data = fn(string $k): string =>
            preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)($_GET[$k] ?? '')) ? (string)$_GET[$k] : '';

        $cliente = (string)($_GET['cliente_id'] ?? '');
        $forma   = (string)($_GET['forma_pagamento'] ?? '');
        $status  = (string)($_GET['status'] ?? '');

        return [
            'data_ini'        => $data('data_ini'),
            'data_fim'        => $data('data_fim'),
            'cliente_id'      => ($cliente === 'avulso' || ctype_digit($cliente)) ? $cliente : '',
            'forma_pagamento' => FormaPagamento::valida($forma) ? $forma : '',
            'status'          => in_array($status, [Venda::CONCLUIDA, Venda::CANCELADA], true) ? $status : '',
        ];
    }

    /** Evita "CSV injection" (células que começam com = + - @ viram fórmulas no Excel). */
    private function csv(string $v): string
    {
        return preg_match('/^[=+\-@\t\r]/', $v) ? "'" . $v : $v;
    }
}
