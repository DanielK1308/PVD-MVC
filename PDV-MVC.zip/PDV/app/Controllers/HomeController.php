<?php
namespace App\Controllers;

use App\Core\Controller;
use App\Repositories\Contracts\VendaRepositoryInterface;

final class HomeController extends Controller
{
    public function __construct(private VendaRepositoryInterface $vendas) {}

    public function indexAction(): void
    {
        $hoje = date('Y-m-d');
        $this->view('home/index', [
            'titulo'     => 'Início',
            'totaisHoje' => $this->vendas->totais(['data_ini' => $hoje, 'data_fim' => $hoje]),
        ]);
    }
}
