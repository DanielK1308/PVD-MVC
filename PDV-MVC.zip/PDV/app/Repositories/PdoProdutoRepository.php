<?php
namespace App\Repositories;

use App\Models\Produto;
use App\Repositories\Contracts\ProdutoRepositoryInterface;

final class PdoProdutoRepository extends BaseRepository implements ProdutoRepositoryInterface
{
    public function paginate(?string $busca, int $page, int $perPage): array
    {
        $where  = '';
        $params = [];
        if ($busca !== null && $busca !== '') {
            $where  = 'WHERE nome ILIKE :q1 OR cod ILIKE :q2 OR categoria ILIKE :q3';
            $params = [
                'q1' => $this->escapeLike($busca),
                'q2' => $this->escapeLike($busca),
                'q3' => $this->escapeLike($busca),
            ];
        }

        $total = (int)$this->run("SELECT COUNT(*) FROM produtos $where", $params)->fetchColumn();

        $params['limite'] = $perPage;
        $params['offset'] = ($page - 1) * $perPage;
        $rows = $this->run(
            "SELECT * FROM produtos $where ORDER BY nome LIMIT :limite OFFSET :offset",
            $params
        )->fetchAll();

        return ['items' => array_map([Produto::class, 'fromArray'], $rows), 'total' => $total];
    }

    public function buscarParaVenda(?string $busca, int $limite = 20): array
    {
        if ($busca !== null && $busca !== '') {
            $rows = $this->run(
                'SELECT * FROM produtos WHERE nome ILIKE :q1 OR cod ILIKE :q2 ORDER BY nome LIMIT :limite',
                ['q1' => $this->escapeLike($busca), 'q2' => $this->escapeLike($busca), 'limite' => $limite]
            )->fetchAll();
        } else {
            $rows = $this->run(
                'SELECT * FROM produtos WHERE quantidade > 0 ORDER BY nome LIMIT :limite',
                ['limite' => $limite]
            )->fetchAll();
        }
        return array_map([Produto::class, 'fromArray'], $rows);
    }

    public function find(int $id): ?Produto
    {
        $row = $this->run('SELECT * FROM produtos WHERE id = :id', ['id' => $id])->fetch();
        return $row ? Produto::fromArray($row) : null;
    }

    public function findMany(array $ids): array
    {
        $ids = array_values(array_unique(array_map('intval', $ids)));
        if ($ids === []) {
            return [];
        }
        $params = [];
        $holders = [];
        foreach ($ids as $i => $id) {
            $holders[] = ':id' . $i;
            $params['id' . $i] = $id;
        }
        $rows = $this->run('SELECT * FROM produtos WHERE id IN (' . implode(',', $holders) . ')', $params)->fetchAll();

        $map = [];
        foreach ($rows as $row) {
            $p = Produto::fromArray($row);
            $map[$p->id] = $p;
        }
        return $map;
    }

    public function findByCod(string $cod, ?int $ignorarId = null): ?Produto
    {
        $row = $this->run(
            'SELECT * FROM produtos WHERE cod = :cod AND id <> :id',
            ['cod' => $cod, 'id' => $ignorarId ?? 0]
        )->fetch();
        return $row ? Produto::fromArray($row) : null;
    }

    public function lockForUpdate(int $id): ?Produto
    {
        $row = $this->run('SELECT * FROM produtos WHERE id = :id FOR UPDATE', ['id' => $id])->fetch();
        return $row ? Produto::fromArray($row) : null;
    }

    public function save(Produto $p): int
    {
        $params = [
            'cod'            => $p->cod,
            'nome'           => $p->nome,
            'categoria'      => $p->categoria,
            'validade'       => $p->validade,
            'quantidade'     => $p->quantidade,
            'preco_unitario' => (string)$p->preco_unitario,
            'preco_pacote'   => (string)$p->preco_pacote,
            'imagem'         => $p->imagem,
        ];

        if ($p->id === null) {
            return (int)$this->run(
                'INSERT INTO produtos (cod, nome, categoria, validade, quantidade, preco_unitario, preco_pacote, imagem)
                 VALUES (:cod, :nome, :categoria, CAST(:validade AS DATE), :quantidade,
                         CAST(:preco_unitario AS NUMERIC), CAST(:preco_pacote AS NUMERIC), :imagem)
                 RETURNING id',
                $params
            )->fetchColumn();
        }

        $params['id'] = $p->id;
        $this->run(
            'UPDATE produtos SET cod = :cod, nome = :nome, categoria = :categoria,
                    validade = CAST(:validade AS DATE), quantidade = :quantidade,
                    preco_unitario = CAST(:preco_unitario AS NUMERIC), preco_pacote = CAST(:preco_pacote AS NUMERIC),
                    imagem = :imagem
             WHERE id = :id',
            $params
        );
        return $p->id;
    }

    public function ajustarEstoque(int $id, int $delta): void
    {
        $this->run('UPDATE produtos SET quantidade = quantidade + :delta WHERE id = :id', [
            'delta' => $delta,
            'id'    => $id,
        ]);
    }

    public function delete(int $id): bool
    {
        return $this->run('DELETE FROM produtos WHERE id = :id', ['id' => $id])->rowCount() > 0;
    }
}
