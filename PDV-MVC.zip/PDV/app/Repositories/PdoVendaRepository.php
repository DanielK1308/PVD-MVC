<?php
namespace App\Repositories;

use App\Models\ItemVenda;
use App\Models\Venda;
use App\Repositories\Contracts\VendaRepositoryInterface;

final class PdoVendaRepository extends BaseRepository implements VendaRepositoryInterface
{
    private const SELECT = 'SELECT v.*, c.nome AS cliente_nome
                            FROM vendas v LEFT JOIN clientes c ON c.id = v.cliente_id';

    public function paginate(array $filtros, int $page, int $perPage): array
    {
        [$where, $params] = $this->where($filtros);

        $total = (int)$this->run("SELECT COUNT(*) FROM vendas v $where", $params)->fetchColumn();

        $params['limite'] = $perPage;
        $params['offset'] = ($page - 1) * $perPage;
        $rows = $this->run(
            self::SELECT . " $where ORDER BY v.criado_em DESC, v.id DESC LIMIT :limite OFFSET :offset",
            $params
        )->fetchAll();

        return ['items' => array_map([Venda::class, 'fromArray'], $rows), 'total' => $total];
    }

    public function listar(array $filtros): array
    {
        [$where, $params] = $this->where($filtros);
        $rows = $this->run(self::SELECT . " $where ORDER BY v.criado_em DESC, v.id DESC", $params)->fetchAll();
        return array_map([Venda::class, 'fromArray'], $rows);
    }

    public function find(int $id): ?Venda
    {
        $row = $this->run(self::SELECT . ' WHERE v.id = :id', ['id' => $id])->fetch();
        if (!$row) {
            return null;
        }
        $venda = Venda::fromArray($row);
        $itens = $this->run('SELECT * FROM itens_venda WHERE venda_id = :id ORDER BY id', ['id' => $id])->fetchAll();
        $venda->itens = array_map([ItemVenda::class, 'fromArray'], $itens);
        return $venda;
    }

    public function inserir(Venda $v): int
    {
        return (int)$this->run(
            'INSERT INTO vendas (cliente_id, subtotal, desconto_tipo, desconto_valor, desconto, total, forma_pagamento, status, observacoes)
             VALUES (:cliente_id, CAST(:subtotal AS NUMERIC), :desconto_tipo, CAST(:desconto_valor AS NUMERIC),
                     CAST(:desconto AS NUMERIC), CAST(:total AS NUMERIC), :forma_pagamento, :status, :observacoes)
             RETURNING id',
            [
                'cliente_id'      => $v->cliente_id,
                'subtotal'        => (string)$v->subtotal,
                'desconto_tipo'   => $v->desconto_tipo,
                'desconto_valor'  => (string)$v->desconto_valor,
                'desconto'        => (string)$v->desconto,
                'total'           => (string)$v->total,
                'forma_pagamento' => $v->forma_pagamento,
                'status'          => $v->status,
                'observacoes'     => $v->observacoes,
            ]
        )->fetchColumn();
    }

    public function inserirItem(ItemVenda $i): void
    {
        $this->run(
            'INSERT INTO itens_venda (venda_id, produto_id, produto_cod, produto_nome, quantidade, preco_unitario, subtotal)
             VALUES (:venda_id, :produto_id, :produto_cod, :produto_nome, :quantidade,
                     CAST(:preco_unitario AS NUMERIC), CAST(:subtotal AS NUMERIC))',
            [
                'venda_id'       => $i->venda_id,
                'produto_id'     => $i->produto_id,
                'produto_cod'    => $i->produto_cod,
                'produto_nome'   => $i->produto_nome,
                'quantidade'     => $i->quantidade,
                'preco_unitario' => (string)$i->preco_unitario,
                'subtotal'       => (string)$i->subtotal,
            ]
        );
    }

    public function atualizarDados(int $id, ?int $clienteId, string $formaPagamento, ?string $observacoes): void
    {
        $this->run(
            'UPDATE vendas SET cliente_id = :cliente_id, forma_pagamento = :forma, observacoes = :obs WHERE id = :id',
            ['cliente_id' => $clienteId, 'forma' => $formaPagamento, 'obs' => $observacoes, 'id' => $id]
        );
    }

    public function marcarCancelada(int $id): bool
    {
        return $this->run(
            "UPDATE vendas SET status = 'cancelada', cancelada_em = now() WHERE id = :id AND status = 'concluida'",
            ['id' => $id]
        )->rowCount() > 0;
    }

    public function delete(int $id): bool
    {
        return $this->run('DELETE FROM vendas WHERE id = :id', ['id' => $id])->rowCount() > 0;
    }

    // ------------------------------------------------------------------
    // Consultas do relatório
    // ------------------------------------------------------------------

    public function totais(array $filtros): array
    {
        [$where, $params] = $this->where($filtros);
        return $this->run(
            "SELECT
                COUNT(*) FILTER (WHERE v.status = 'concluida')                          AS qtd_concluidas,
                COUNT(*) FILTER (WHERE v.status = 'cancelada')                          AS qtd_canceladas,
                COALESCE(SUM(v.subtotal) FILTER (WHERE v.status = 'concluida'), 0)      AS bruto,
                COALESCE(SUM(v.desconto) FILTER (WHERE v.status = 'concluida'), 0)      AS descontos,
                COALESCE(SUM(v.total)    FILTER (WHERE v.status = 'concluida'), 0)      AS liquido,
                COALESCE(AVG(v.total)    FILTER (WHERE v.status = 'concluida'), 0)      AS ticket_medio
             FROM vendas v $where",
            $params
        )->fetch() ?: [];
    }

    public function topProdutos(array $filtros, int $limite = 10): array
    {
        [$where, $params] = $this->where($filtros, true);
        $params['limite'] = $limite;
        return $this->run(
            "SELECT i.produto_cod, i.produto_nome,
                    SUM(i.quantidade) AS qtd, SUM(i.subtotal) AS total
             FROM itens_venda i JOIN vendas v ON v.id = i.venda_id
             $where
             GROUP BY i.produto_cod, i.produto_nome
             ORDER BY SUM(i.quantidade) DESC, SUM(i.subtotal) DESC
             LIMIT :limite",
            $params
        )->fetchAll();
    }

    public function porDia(array $filtros): array
    {
        [$where, $params] = $this->where($filtros, true);
        return $this->run(
            "SELECT CAST(v.criado_em AT TIME ZONE 'America/Cuiaba' AS DATE) AS dia, COUNT(*) AS qtd, SUM(v.total) AS total
             FROM vendas v $where
             GROUP BY CAST(v.criado_em AT TIME ZONE 'America/Cuiaba' AS DATE)
             ORDER BY CAST(v.criado_em AT TIME ZONE 'America/Cuiaba' AS DATE)",
            $params
        )->fetchAll();
    }

    public function porFormaPagamento(array $filtros): array
    {
        [$where, $params] = $this->where($filtros, true);
        return $this->run(
            "SELECT v.forma_pagamento, COUNT(*) AS qtd, SUM(v.total) AS total
             FROM vendas v $where
             GROUP BY v.forma_pagamento
             ORDER BY SUM(v.total) DESC",
            $params
        )->fetchAll();
    }

    /**
     * Monta o WHERE a partir dos filtros (todos opcionais).
     * As datas são convertidas para America/Cuiaba na própria consulta, sem depender
     * do fuso da sessão (o pooler do Neon pode não preservar SET TIME ZONE).
     * @return array{0: string, 1: array}
     */
    private function where(array $f, bool $somenteConcluidas = false): array
    {
        $w = [];
        $p = [];

        if (!empty($f['data_ini'])) {
            $w[] = "(v.criado_em AT TIME ZONE 'America/Cuiaba') >= CAST(:data_ini AS DATE)";
            $p['data_ini'] = $f['data_ini'];
        }
        if (!empty($f['data_fim'])) {
            $w[] = "(v.criado_em AT TIME ZONE 'America/Cuiaba') < CAST(:data_fim AS DATE) + INTERVAL '1 day'";
            $p['data_fim'] = $f['data_fim'];
        }
        if (!empty($f['cliente_id'])) {
            if ($f['cliente_id'] === 'avulso') {
                $w[] = 'v.cliente_id IS NULL';
            } else {
                $w[] = 'v.cliente_id = :cliente_id';
                $p['cliente_id'] = (int)$f['cliente_id'];
            }
        }
        if (!empty($f['forma_pagamento'])) {
            $w[] = 'v.forma_pagamento = :forma_pagamento';
            $p['forma_pagamento'] = $f['forma_pagamento'];
        }
        if (!empty($f['status'])) {
            $w[] = 'v.status = :status';
            $p['status'] = $f['status'];
        }
        if ($somenteConcluidas) {
            $w[] = "v.status = 'concluida'";
        }

        return [$w ? 'WHERE ' . implode(' AND ', $w) : '', $p];
    }
}
