<?php
namespace App\Repositories;

use PDO;
use PDOStatement;

/**
 * DESIGN PATTERN: Repository (base).
 * Centraliza prepared statements: nenhum SQL vive em controllers ou views.
 */
abstract class BaseRepository
{
    public function __construct(protected PDO $pdo) {}

    /** Prepara, faz o bind com o tipo correto e executa. Aceita parâmetros nomeados. */
    protected function run(string $sql, array $params = []): PDOStatement
    {
        $stmt = $this->pdo->prepare($sql);
        foreach ($params as $name => $value) {
            $type = match (true) {
                is_int($value)  => PDO::PARAM_INT,
                is_bool($value) => PDO::PARAM_BOOL,
                is_null($value) => PDO::PARAM_NULL,
                default         => PDO::PARAM_STR,
            };
            $stmt->bindValue(':' . ltrim((string)$name, ':'), $value, $type);
        }
        $stmt->execute();
        return $stmt;
    }

    protected function escapeLike(string $s): string
    {
        return '%' . addcslashes($s, '%_\\') . '%';
    }
}
