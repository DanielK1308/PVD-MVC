<?php
namespace App\Repositories;

use App\Models\Cliente;
use App\Repositories\Contracts\ClienteRepositoryInterface;

final class PdoClienteRepository extends BaseRepository implements ClienteRepositoryInterface
{
    public function paginate(?string $busca, int $page, int $perPage): array
    {
        $where  = '';
        $params = [];

        if ($busca !== null && $busca !== '') {
            $conds = ['nome ILIKE :q1', 'email ILIKE :q2', 'telefone ILIKE :q3'];
            $params = [
                'q1' => $this->escapeLike($busca),
                'q2' => $this->escapeLike($busca),
                'q3' => $this->escapeLike($busca),
            ];
            $digits = preg_replace('/\D/', '', $busca);
            if ($digits !== '') {
                $conds[] = 'cpf_cnpj LIKE :q4';
                $params['q4'] = '%' . $digits . '%';
            }
            $where = 'WHERE ' . implode(' OR ', $conds);
        }

        $total = (int)$this->run("SELECT COUNT(*) FROM clientes $where", $params)->fetchColumn();

        $params['limite']  = $perPage;
        $params['offset']  = ($page - 1) * $perPage;
        $rows = $this->run(
            "SELECT * FROM clientes $where ORDER BY nome LIMIT :limite OFFSET :offset",
            $params
        )->fetchAll();

        return ['items' => array_map([Cliente::class, 'fromArray'], $rows), 'total' => $total];
    }

    public function ativos(): array
    {
        $rows = $this->run('SELECT * FROM clientes WHERE ativo = TRUE ORDER BY nome')->fetchAll();
        return array_map([Cliente::class, 'fromArray'], $rows);
    }

    public function find(int $id): ?Cliente
    {
        $row = $this->run('SELECT * FROM clientes WHERE id = :id', ['id' => $id])->fetch();
        return $row ? Cliente::fromArray($row) : null;
    }

    public function findByDocumento(string $digits, ?int $ignorarId = null): ?Cliente
    {
        $row = $this->run(
            'SELECT * FROM clientes WHERE cpf_cnpj = :doc AND id <> :id',
            ['doc' => $digits, 'id' => $ignorarId ?? 0]
        )->fetch();
        return $row ? Cliente::fromArray($row) : null;
    }

    public function save(Cliente $c): int
    {
        $params = [
            'nome'        => $c->nome,
            'cpf_cnpj'    => $c->cpf_cnpj,
            'email'       => $c->email,
            'telefone'    => $c->telefone,
            'cep'         => $c->cep,
            'endereco'    => $c->endereco,
            'numero'      => $c->numero,
            'bairro'      => $c->bairro,
            'cidade'      => $c->cidade,
            'uf'          => $c->uf,
            'observacoes' => $c->observacoes,
            'ativo'       => $c->ativo ? 'true' : 'false',
        ];

        if ($c->id === null) {
            return (int)$this->run(
                'INSERT INTO clientes (nome, cpf_cnpj, email, telefone, cep, endereco, numero, bairro, cidade, uf, observacoes, ativo)
                 VALUES (:nome, :cpf_cnpj, :email, :telefone, :cep, :endereco, :numero, :bairro, :cidade, :uf, :observacoes, CAST(:ativo AS BOOLEAN))
                 RETURNING id',
                $params
            )->fetchColumn();
        }

        $params['id'] = $c->id;
        $this->run(
            'UPDATE clientes SET nome = :nome, cpf_cnpj = :cpf_cnpj, email = :email, telefone = :telefone,
                    cep = :cep, endereco = :endereco, numero = :numero, bairro = :bairro, cidade = :cidade,
                    uf = :uf, observacoes = :observacoes, ativo = CAST(:ativo AS BOOLEAN), atualizado_em = now()
             WHERE id = :id',
            $params
        );
        return $c->id;
    }

    public function delete(int $id): bool
    {
        return $this->run('DELETE FROM clientes WHERE id = :id', ['id' => $id])->rowCount() > 0;
    }
}
