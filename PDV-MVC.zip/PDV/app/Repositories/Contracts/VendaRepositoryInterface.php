<?php
namespace App\Repositories\Contracts;

use App\Models\ItemVenda;
use App\Models\Venda;

interface VendaRepositoryInterface
{
    /** @return array{items: Venda[], total: int} */
    public function paginate(array $filtros, int $page, int $perPage): array;

    /** @return Venda[] (sem paginação — exportação) */
    public function listar(array $filtros): array;

    public function find(int $id): ?Venda;

    public function inserir(Venda $venda): int;

    public function inserirItem(ItemVenda $item): void;

    public function atualizarDados(int $id, ?int $clienteId, string $formaPagamento, ?string $observacoes): void;

    /** Retorna true se a venda estava concluída e foi cancelada. */
    public function marcarCancelada(int $id): bool;

    public function delete(int $id): bool;

    // --- consultas do relatório ---
    public function totais(array $filtros): array;
    public function topProdutos(array $filtros, int $limite = 10): array;
    public function porDia(array $filtros): array;
    public function porFormaPagamento(array $filtros): array;
}
