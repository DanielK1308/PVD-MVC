<?php
namespace App\Repositories\Contracts;

use App\Models\Produto;

interface ProdutoRepositoryInterface
{
    /** @return array{items: Produto[], total: int} */
    public function paginate(?string $busca, int $page, int $perPage): array;

    /** @return Produto[] */
    public function buscarParaVenda(?string $busca, int $limite = 20): array;

    public function find(int $id): ?Produto;

    /** @param int[] $ids  @return array<int, Produto> indexado pelo id */
    public function findMany(array $ids): array;

    public function findByCod(string $cod, ?int $ignorarId = null): ?Produto;

    /** SELECT ... FOR UPDATE (use dentro de transação). */
    public function lockForUpdate(int $id): ?Produto;

    public function save(Produto $produto): int;

    public function ajustarEstoque(int $id, int $delta): void;

    public function delete(int $id): bool;
}
