<?php
namespace App\Repositories\Contracts;

use App\Models\Cliente;

interface ClienteRepositoryInterface
{
    /** @return array{items: Cliente[], total: int} */
    public function paginate(?string $busca, int $page, int $perPage): array;

    /** @return Cliente[] */
    public function ativos(): array;

    public function find(int $id): ?Cliente;

    public function findByDocumento(string $digits, ?int $ignorarId = null): ?Cliente;

    /** Insere (id nulo) ou atualiza. Retorna o id. */
    public function save(Cliente $cliente): int;

    public function delete(int $id): bool;
}
