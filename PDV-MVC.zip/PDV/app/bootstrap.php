<?php
/**
 * Bootstrap: constantes, autoload PSR-4 (namespace App\ => /app), helpers,
 * variáveis de ambiente, fuso horário e sessão.
 */
define('APP_PATH', __DIR__);
define('BASE_PATH', dirname(__DIR__));

spl_autoload_register(function (string $class): void {
    $prefix = 'App\\';
    if (strncmp($class, $prefix, strlen($prefix)) !== 0) {
        return;
    }
    $file = APP_PATH . '/' . str_replace('\\', '/', substr($class, strlen($prefix))) . '.php';
    if (is_file($file)) {
        require $file;
    }
});

require APP_PATH . '/Core/helpers.php';

date_default_timezone_set('America/Cuiaba');

App\Core\Env::load(BASE_PATH . '/.env');
App\Core\Session::start();

if (App\Core\Env::get('APP_DEBUG') === '1') {
    ini_set('display_errors', '1');
    error_reporting(E_ALL);
} else {
    ini_set('display_errors', '0');
}
