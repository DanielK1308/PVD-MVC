<?php
namespace App\Strategies;

final class DescontoValorFixo implements DescontoInterface
{
    public function __construct(private float $valor) {}

    public function calcular(float $subtotal): float
    {
        return round(min(max($this->valor, 0.0), $subtotal), 2);
    }

    public function tipo(): string { return 'valor'; }
    public function valor(): float { return max($this->valor, 0.0); }
}
