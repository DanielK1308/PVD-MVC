<?php
namespace App\Strategies;

/** DESIGN PATTERN: Factory — escolhe a estratégia de desconto a partir do formulário. */
final class DescontoFactory
{
    public static function criar(string $tipo, float $valor): DescontoInterface
    {
        return match ($tipo) {
            'percentual' => new DescontoPercentual($valor),
            'valor'      => new DescontoValorFixo($valor),
            default      => new SemDesconto(),
        };
    }
}
