<?php
namespace App\Strategies;

final class DescontoPercentual implements DescontoInterface
{
    public function __construct(private float $percentual) {}

    public function calcular(float $subtotal): float
    {
        $p = min(max($this->percentual, 0.0), 100.0);
        return round($subtotal * $p / 100, 2);
    }

    public function tipo(): string { return 'percentual'; }
    public function valor(): float { return min(max($this->percentual, 0.0), 100.0); }
}
