<?php
namespace App\Strategies;

final class SemDesconto implements DescontoInterface
{
    public function calcular(float $subtotal): float { return 0.0; }
    public function tipo(): string { return 'nenhum'; }
    public function valor(): float { return 0.0; }
}
