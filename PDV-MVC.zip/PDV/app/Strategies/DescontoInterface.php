<?php
namespace App\Strategies;

/** DESIGN PATTERN: Strategy — cada tipo de desconto é uma estratégia intercambiável. */
interface DescontoInterface
{
    public function calcular(float $subtotal): float;
    public function tipo(): string;
    public function valor(): float;
}
