<?php
namespace App\Core;

/** Controller base: render, redirect, flash, proteção CSRF e utilidades. */
abstract class Controller
{
    protected function view(string $view, array $data = []): void
    {
        View::render($view, $data);
    }

    protected function redirect(string $route, array $params = []): void
    {
        header('Location: ' . url($route, $params));
        exit;
    }

    protected function flash(string $type, string $message): void
    {
        Session::flash($type, $message);
    }

    protected function isPost(): bool
    {
        return ($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'POST';
    }

    /** Exige POST + token CSRF válido (todas as ações que alteram dados). */
    protected function requirePost(): void
    {
        if (!$this->isPost()) {
            http_response_code(405);
            exit('Método não permitido.');
        }
        if (!Csrf::validate($_POST['_csrf'] ?? null)) {
            http_response_code(419);
            exit('Token de segurança inválido. Volte e recarregue a página.');
        }
    }

    protected function page(): int
    {
        return max(1, (int)($_GET['page'] ?? 1));
    }

    protected function idGet(): int
    {
        return (int)($_GET['id'] ?? 0);
    }

    protected function idPost(string $key = 'id'): int
    {
        return (int)($_POST[$key] ?? 0);
    }
}
