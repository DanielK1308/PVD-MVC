<?php
namespace App\Core;

/** Validador simples com mensagens em português. */
final class Validator
{
    private array $errors = [];

    public function required(string $field, mixed $value, string $label): self
    {
        if (trim((string)$value) === '') {
            $this->errors[$field] ??= "$label é obrigatório.";
        }
        return $this;
    }

    public function maxLength(string $field, ?string $value, int $max, string $label): self
    {
        if ($value !== null && mb_strlen($value) > $max) {
            $this->errors[$field] ??= "$label deve ter no máximo $max caracteres.";
        }
        return $this;
    }

    public function email(string $field, ?string $value, string $label = 'E-mail'): self
    {
        if ($value !== null && $value !== '' && !filter_var($value, FILTER_VALIDATE_EMAIL)) {
            $this->errors[$field] ??= "$label inválido.";
        }
        return $this;
    }

    /** CPF (11 dígitos) ou CNPJ (14 dígitos), apenas dígitos. */
    public function documento(string $field, ?string $digits, string $label = 'CPF/CNPJ'): self
    {
        if ($digits === null || $digits === '') {
            return $this;
        }
        $ok = match (strlen($digits)) {
            11 => self::cpf($digits),
            14 => self::cnpj($digits),
            default => false,
        };
        if (!$ok) {
            $this->errors[$field] ??= "$label inválido.";
        }
        return $this;
    }

    public function min(string $field, float|int $value, float|int $min, string $label): self
    {
        if ($value < $min) {
            $this->errors[$field] ??= "$label deve ser maior ou igual a $min.";
        }
        return $this;
    }

    public function uf(string $field, ?string $value): self
    {
        if ($value !== null && $value !== '' && !preg_match('/^[A-Z]{2}$/', $value)) {
            $this->errors[$field] ??= 'UF deve ter 2 letras.';
        }
        return $this;
    }

    public function addError(string $field, string $message): self
    {
        $this->errors[$field] = $message;
        return $this;
    }

    public function fails(): bool
    {
        return $this->errors !== [];
    }

    public function errors(): array
    {
        return $this->errors;
    }

    private static function cpf(string $d): bool
    {
        if (strlen($d) !== 11 || preg_match('/^(\d)\1{10}$/', $d)) {
            return false;
        }
        for ($t = 9; $t < 11; $t++) {
            $sum = 0;
            for ($i = 0; $i < $t; $i++) {
                $sum += (int)$d[$i] * (($t + 1) - $i);
            }
            if ((int)$d[$t] !== ((10 * $sum) % 11) % 10) {
                return false;
            }
        }
        return true;
    }

    private static function cnpj(string $d): bool
    {
        if (strlen($d) !== 14 || preg_match('/^(\d)\1{13}$/', $d)) {
            return false;
        }
        foreach ([12, 13] as $len) {
            $weights = $len === 12
                ? [5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2]
                : [6, 5, 4, 3, 2, 9, 8, 7, 6, 5, 4, 3, 2];
            $sum = 0;
            foreach ($weights as $i => $w) {
                $sum += (int)$d[$i] * $w;
            }
            $r   = $sum % 11;
            $dig = $r < 2 ? 0 : 11 - $r;
            if ((int)$d[$len] !== $dig) {
                return false;
            }
        }
        return true;
    }
}
