<?php
namespace App\Core;

/**
 * DESIGN PATTERN: Front Controller (via index.php) + Router.
 * Rota no formato ?r=controller/acao  ->  XxxController::acaoAction()
 */
final class Router
{
    /** @var array<string, class-string> */
    private array $controllers = [];

    public function __construct(private Container $container) {}

    public function register(string $name, string $controllerClass): self
    {
        $this->controllers[$name] = $controllerClass;
        return $this;
    }

    public function dispatch(): void
    {
        $route  = trim((string)($_GET['r'] ?? 'home/index'), '/');
        $parts  = explode('/', $route);
        $name   = $parts[0] !== '' ? $parts[0] : 'home';
        $action = $parts[1] ?? 'index';

        if (!preg_match('/^[a-z]+$/', $name) || !preg_match('/^[a-z]+$/', $action)
            || !isset($this->controllers[$name])) {
            $this->notFound();
            return;
        }

        $controller = $this->container->get($this->controllers[$name]);
        $method     = $action . 'Action';

        if (!method_exists($controller, $method)) {
            $this->notFound();
            return;
        }
        $controller->$method();
    }

    private function notFound(): void
    {
        http_response_code(404);
        View::render('erros/404', ['titulo' => 'Página não encontrada']);
    }
}
