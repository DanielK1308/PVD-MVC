<?php
namespace App\Core;

use ReflectionClass;
use ReflectionNamedType;
use RuntimeException;

/**
 * DESIGN PATTERN: Dependency Injection (Container com autowiring).
 * Interfaces e PDO são ligados explicitamente em index.php; o resto
 * (controllers, services, repositórios) é resolvido pelo construtor.
 */
final class Container
{
    /** @var array<string, callable> */
    private array $factories = [];
    /** @var array<string, object> */
    private array $instances = [];

    public function bind(string $id, callable $factory): void
    {
        $this->factories[$id] = $factory;
    }

    public function get(string $id): object
    {
        if (isset($this->instances[$id])) {
            return $this->instances[$id];
        }
        $object = isset($this->factories[$id])
            ? ($this->factories[$id])($this)
            : $this->autowire($id);

        return $this->instances[$id] = $object;
    }

    private function autowire(string $class): object
    {
        if (!class_exists($class)) {
            throw new RuntimeException("Serviço não registrado: $class");
        }
        $ref  = new ReflectionClass($class);
        $ctor = $ref->getConstructor();
        if ($ctor === null) {
            return new $class();
        }

        $args = [];
        foreach ($ctor->getParameters() as $param) {
            $type = $param->getType();
            if ($type instanceof ReflectionNamedType && !$type->isBuiltin()) {
                $args[] = $this->get($type->getName());
            } elseif ($param->isDefaultValueAvailable()) {
                $args[] = $param->getDefaultValue();
            } else {
                throw new RuntimeException("Não foi possível resolver \${$param->getName()} de $class");
            }
        }
        return $ref->newInstanceArgs($args);
    }
}
