<?php
use App\Core\Csrf;
use App\Core\Session;
use App\Core\View;

/** Escapa para HTML. */
function e(mixed $v): string
{
    return htmlspecialchars((string)($v ?? ''), ENT_QUOTES, 'UTF-8');
}

/** URL da rota (sem escapar; use href() dentro de atributos HTML). */
function url(string $route = 'home/index', array $params = []): string
{
    return 'index.php?' . http_build_query(['r' => $route] + $params);
}

function href(string $route = 'home/index', array $params = []): string
{
    return e(url($route, $params));
}

function money(float|int|string|null $v): string
{
    return 'R$ ' . number_format((float)$v, 2, ',', '.');
}

function data_br(?string $v, bool $hora = false): string
{
    if (empty($v)) {
        return '—';
    }
    try {
        $d = new DateTime($v);
        $d->setTimezone(new DateTimeZone('America/Cuiaba'));
        return $d->format($hora ? 'd/m/Y H:i' : 'd/m/Y');
    } catch (Exception $e) {
        return (string)$v;
    }
}

function doc_fmt(?string $d): string
{
    $d = preg_replace('/\D/', '', (string)$d);
    if (strlen($d) === 11) {
        return preg_replace('/(\d{3})(\d{3})(\d{3})(\d{2})/', '$1.$2.$3-$4', $d);
    }
    if (strlen($d) === 14) {
        return preg_replace('/(\d{2})(\d{3})(\d{3})(\d{4})(\d{2})/', '$1.$2.$3/$4-$5', $d);
    }
    return $d === '' ? '—' : $d;
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . e(Csrf::token()) . '">';
}

function invalid(array $errors, string $field): string
{
    return isset($errors[$field]) ? ' is-invalid' : '';
}

function feedback(array $errors, string $field): string
{
    return isset($errors[$field]) ? '<div class="invalid-feedback">' . e($errors[$field]) . '</div>' : '';
}

function rota_atual(): string
{
    $parts = explode('/', (string)($_GET['r'] ?? 'home/index'));
    return $parts[0] !== '' ? $parts[0] : 'home';
}

function carrinho_qtd(): int
{
    $c = Session::get('_carrinho', []);
    return (int)array_sum($c['itens'] ?? []);
}

function partial(string $view, array $data = []): void
{
    View::partial($view, $data);
}
