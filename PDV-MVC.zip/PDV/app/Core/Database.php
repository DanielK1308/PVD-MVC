<?php
namespace App\Core;

use PDO;
use RuntimeException;

/**
 * DESIGN PATTERN: Singleton.
 * Garante uma única conexão PDO (Neon PostgreSQL) por requisição.
 */
final class Database
{
    private static ?PDO $instance = null;

    private function __construct() {}
    private function __clone() {}

    public static function getInstance(): PDO
    {
        if (self::$instance === null) {
            self::$instance = self::connect();
        }
        return self::$instance;
    }

    private static function connect(): PDO
    {
        $connectionString = Env::get('SRVDB');
        if (empty($connectionString)) {
            throw new RuntimeException('Chave SRVDB não encontrada no arquivo .env.');
        }

        $url = parse_url($connectionString);
        if (!$url || !isset($url['host'])) {
            throw new RuntimeException('Formato da chave SRVDB inválido no .env.');
        }

        $host     = $url['host'];
        $port     = $url['port'] ?? 5432;
        $user     = isset($url['user']) ? urldecode($url['user']) : '';
        $password = isset($url['pass']) ? urldecode($url['pass']) : '';
        $dbname   = ltrim($url['path'] ?? '', '/');

        // Neon: informa o endpoint ID nas opções (mesma solução do db.php original)
        $endpointId = explode('.', $host)[0];
        $dsn = "pgsql:host=$host;port=$port;dbname=$dbname;sslmode=require;options='endpoint=$endpointId'";

        $pdo = new PDO($dsn, $user, $password, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
        $pdo->exec("SET TIME ZONE 'America/Cuiaba'");

        return $pdo;
    }
}
