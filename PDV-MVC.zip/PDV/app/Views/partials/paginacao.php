<?php
/** Espera: $route, $params (filtros), $page, $perPage, $total */
$totalPaginas = max(1, (int)ceil($total / $perPage));
if ($totalPaginas > 1):
    $link   = fn(int $p): string => href($route, array_merge($params, ['page' => $p]));
    $inicio = max(1, $page - 3);
    $fim    = min($totalPaginas, $page + 3);
?>
<nav class="no-print" aria-label="Paginação">
    <ul class="pagination pagination-sm justify-content-center mb-0">
        <li class="page-item <?= $page <= 1 ? 'disabled' : '' ?>">
            <a class="page-link" href="<?= $link(max(1, $page - 1)) ?>">&laquo;</a>
        </li>
        <?php for ($p = $inicio; $p <= $fim; $p++): ?>
            <li class="page-item <?= $p === $page ? 'active' : '' ?>">
                <a class="page-link" href="<?= $link($p) ?>"><?= $p ?></a>
            </li>
        <?php endfor; ?>
        <li class="page-item <?= $page >= $totalPaginas ? 'disabled' : '' ?>">
            <a class="page-link" href="<?= $link(min($totalPaginas, $page + 1)) ?>">&raquo;</a>
        </li>
    </ul>
</nav>
<?php endif; ?>
