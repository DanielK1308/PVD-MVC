<div class="text-center py-5">
    <h1 class="display-4">404</h1>
    <p class="lead">Página não encontrada.</p>
    <a class="btn btn-primary" href="<?= href('home/index') ?>">Voltar ao início</a>
</div>
