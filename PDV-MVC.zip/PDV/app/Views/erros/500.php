<div class="text-center py-5">
    <h1 class="display-4">Ops!</h1>
    <p class="lead">Ocorreu um erro inesperado. Tente novamente em instantes.</p>
    <?php if (!empty($detalhe)): ?>
        <pre class="text-start bg-white border rounded p-3 small"><?= e($detalhe) ?></pre>
    <?php endif; ?>
    <a class="btn btn-primary" href="<?= href('home/index') ?>">Voltar ao início</a>
</div>
