<?php
use App\Models\FormaPagamento;
/** @var App\Models\Venda $venda @var App\Models\Cliente[] $clientes */
$clienteAtualNaLista = false;
foreach ($clientes as $c) {
    if ($c->id === $venda->cliente_id) { $clienteAtualNaLista = true; break; }
}
?>
<h1 class="h3 mb-3">Editar venda #<?= (int)$venda->id ?></h1>
<div class="alert alert-info">Itens, quantidades e valores não podem ser alterados. Para corrigi-los, cancele a venda e registre uma nova no carrinho.</div>

<form method="POST" action="<?= href('relatorios/atualizar') ?>" class="card shadow-sm">
    <div class="card-body">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= (int)$venda->id ?>">
        <div class="row g-3">
            <div class="col-md-6">
                <label class="form-label" for="cliente_id">Cliente</label>
                <select name="cliente_id" id="cliente_id" class="form-select">
                    <option value="0">Consumidor final</option>
                    <?php if ($venda->cliente_id && !$clienteAtualNaLista): ?>
                        <option value="<?= (int)$venda->cliente_id ?>" selected><?= e($venda->cliente_nome) ?> (inativo)</option>
                    <?php endif; ?>
                    <?php foreach ($clientes as $c): ?>
                        <option value="<?= (int)$c->id ?>" <?= $venda->cliente_id === $c->id ? 'selected' : '' ?>><?= e($c->nome) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-md-6">
                <label class="form-label" for="forma_pagamento">Forma de pagamento</label>
                <select name="forma_pagamento" id="forma_pagamento" class="form-select">
                    <?php foreach (FormaPagamento::LISTA as $cod => $rotulo): ?>
                        <option value="<?= e($cod) ?>" <?= $venda->forma_pagamento === $cod ? 'selected' : '' ?>><?= e($rotulo) ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="col-12">
                <label class="form-label" for="observacoes">Observações</label>
                <textarea name="observacoes" id="observacoes" rows="3" maxlength="500" class="form-control"><?= e($venda->observacoes) ?></textarea>
            </div>
        </div>
    </div>
    <div class="card-footer d-flex justify-content-between">
        <a href="<?= href('relatorios/ver', ['id' => $venda->id]) ?>" class="btn btn-secondary">Voltar</a>
        <button type="submit" class="btn btn-primary">Salvar alterações</button>
    </div>
</form>
