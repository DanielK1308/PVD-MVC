<?php
use App\Models\FormaPagamento;
/** @var App\Models\Venda $venda */
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <h1 class="h3 mb-0">
        Venda #<?= (int)$venda->id ?>
        <span class="badge text-bg-<?= $venda->concluida() ? 'success' : 'secondary' ?> align-middle fs-6"><?= $venda->concluida() ? 'Concluída' : 'Cancelada' ?></span>
    </h1>
    <div class="d-flex gap-2 no-print">
        <a href="<?= href('relatorios/index') ?>" class="btn btn-secondary">Voltar</a>
        <button type="button" class="btn btn-outline-dark" onclick="window.print()">Imprimir</button>
        <?php if ($venda->concluida()): ?>
            <a href="<?= href('relatorios/editar', ['id' => $venda->id]) ?>" class="btn btn-warning">Editar</a>
            <form method="POST" action="<?= href('relatorios/cancelar') ?>"
                  onsubmit="return confirm('Cancelar esta venda? Os itens voltam ao estoque.')">
                <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$venda->id ?>">
                <button class="btn btn-outline-danger">Cancelar venda</button>
            </form>
        <?php endif; ?>
    </div>
</div>

<div class="row g-3">
    <div class="col-lg-8">
        <div class="card shadow-sm">
            <div class="table-responsive">
                <table class="table align-middle mb-0">
                    <thead class="table-light"><tr><th>Cód.</th><th>Produto</th><th class="text-end">Qtd</th><th class="text-end">Unit.</th><th class="text-end">Subtotal</th></tr></thead>
                    <tbody>
                    <?php foreach ($venda->itens as $i): ?>
                        <tr>
                            <td><?= e($i->produto_cod) ?></td>
                            <td><?= e($i->produto_nome) ?></td>
                            <td class="text-end"><?= (int)$i->quantidade ?></td>
                            <td class="text-end"><?= money($i->preco_unitario) ?></td>
                            <td class="text-end"><?= money($i->subtotal) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                    <tfoot>
                        <tr><td colspan="4" class="text-end text-muted">Subtotal</td><td class="text-end"><?= money($venda->subtotal) ?></td></tr>
                        <tr><td colspan="4" class="text-end text-muted">
                            Desconto<?php if ($venda->desconto_tipo === 'percentual'): ?> (<?= e(rtrim(rtrim(number_format($venda->desconto_valor, 2, ',', ''), '0'), ',')) ?>%)<?php endif; ?>
                        </td><td class="text-end text-danger">− <?= money($venda->desconto) ?></td></tr>
                        <tr class="fs-5"><td colspan="4" class="text-end fw-bold">Total</td><td class="text-end fw-bold"><?= money($venda->total) ?></td></tr>
                    </tfoot>
                </table>
            </div>
        </div>
    </div>
    <div class="col-lg-4">
        <div class="card shadow-sm">
            <div class="card-body">
                <dl class="mb-0">
                    <dt>Data</dt><dd><?= e(data_br($venda->criado_em, true)) ?></dd>
                    <dt>Cliente</dt><dd><?= e($venda->cliente_nome ?? 'Consumidor final') ?></dd>
                    <dt>Pagamento</dt><dd><?= e(FormaPagamento::rotulo($venda->forma_pagamento)) ?></dd>
                    <?php if (!$venda->concluida()): ?>
                        <dt>Cancelada em</dt><dd><?= e(data_br($venda->cancelada_em, true)) ?></dd>
                    <?php endif; ?>
                    <dt>Observações</dt><dd class="mb-0"><?= e($venda->observacoes ?? '—') ?></dd>
                </dl>
            </div>
        </div>
    </div>
</div>
