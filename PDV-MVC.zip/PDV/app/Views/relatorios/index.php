<?php
use App\Models\FormaPagamento;
use App\Models\Venda;
/**
 * @var array $filtros  @var App\Models\Venda[] $vendas  @var array $totais
 * @var array $topProdutos @var array $porDia @var array $porForma
 * @var App\Models\Cliente[] $clientes
 */
$params   = array_filter($filtros, fn($v) => $v !== '');
$labels   = array_map(fn($r) => data_br($r['dia']), $porDia);
$valores  = array_map(fn($r) => round((float)$r['total'], 2), $porDia);
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <h1 class="h3 mb-0">Relatório de vendas</h1>
    <div class="d-flex gap-2 no-print">
        <a href="<?= href('relatorios/exportar', $params) ?>" class="btn btn-outline-success">Exportar CSV</a>
        <a href="<?= href('carrinho/index') ?>" class="btn btn-success">+ Nova venda</a>
    </div>
</div>

<!-- Filtros -->
<form method="GET" action="index.php" class="card shadow-sm mb-4 no-print">
    <input type="hidden" name="r" value="relatorios/index">
    <div class="card-body row g-2 align-items-end">
        <div class="col-6 col-md-2"><label class="form-label mb-1">De</label>
            <input type="date" name="data_ini" value="<?= e($filtros['data_ini']) ?>" class="form-control"></div>
        <div class="col-6 col-md-2"><label class="form-label mb-1">Até</label>
            <input type="date" name="data_fim" value="<?= e($filtros['data_fim']) ?>" class="form-control"></div>
        <div class="col-md-3"><label class="form-label mb-1">Cliente</label>
            <select name="cliente_id" class="form-select">
                <option value="">Todos</option>
                <option value="avulso" <?= $filtros['cliente_id'] === 'avulso' ? 'selected' : '' ?>>Consumidor final</option>
                <?php foreach ($clientes as $c): ?>
                    <option value="<?= (int)$c->id ?>" <?= $filtros['cliente_id'] === (string)$c->id ? 'selected' : '' ?>><?= e($c->nome) ?></option>
                <?php endforeach; ?>
            </select></div>
        <div class="col-6 col-md-2"><label class="form-label mb-1">Pagamento</label>
            <select name="forma_pagamento" class="form-select">
                <option value="">Todos</option>
                <?php foreach (FormaPagamento::LISTA as $cod => $rotulo): ?>
                    <option value="<?= e($cod) ?>" <?= $filtros['forma_pagamento'] === $cod ? 'selected' : '' ?>><?= e($rotulo) ?></option>
                <?php endforeach; ?>
            </select></div>
        <div class="col-6 col-md-1"><label class="form-label mb-1">Status</label>
            <select name="status" class="form-select">
                <option value="">Todos</option>
                <option value="concluida" <?= $filtros['status'] === 'concluida' ? 'selected' : '' ?>>Concluídas</option>
                <option value="cancelada" <?= $filtros['status'] === 'cancelada' ? 'selected' : '' ?>>Canceladas</option>
            </select></div>
        <div class="col-12 col-md-2 d-flex gap-2">
            <button class="btn btn-primary flex-fill">Filtrar</button>
            <a href="<?= href('relatorios/index') ?>" class="btn btn-outline-secondary">Limpar</a>
        </div>
    </div>
</form>

<!-- Indicadores -->
<div class="row g-3 mb-4">
    <?php
    $cards = [
        ['Vendas concluídas', (string)(int)($totais['qtd_concluidas'] ?? 0), ''],
        ['Faturamento líquido', money($totais['liquido'] ?? 0), 'text-success'],
        ['Descontos concedidos', money($totais['descontos'] ?? 0), 'text-danger'],
        ['Ticket médio', money($totais['ticket_medio'] ?? 0), ''],
        ['Canceladas', (string)(int)($totais['qtd_canceladas'] ?? 0), 'text-secondary'],
    ];
    foreach ($cards as [$rotulo, $valor, $cls]): ?>
        <div class="col-6 col-lg">
            <div class="card shadow-sm h-100"><div class="card-body">
                <div class="text-muted small"><?= e($rotulo) ?></div>
                <div class="fs-4 fw-semibold <?= e($cls) ?>"><?= e($valor) ?></div>
            </div></div>
        </div>
    <?php endforeach; ?>
</div>

<!-- Gráfico + rankings -->
<div class="row g-3 mb-4">
    <div class="col-lg-7">
        <div class="card shadow-sm h-100">
            <div class="card-header fw-semibold">Faturamento por dia</div>
            <div class="card-body">
                <?php if ($porDia): ?>
                    <canvas id="graficoDias" height="140"></canvas>
                <?php else: ?>
                    <p class="text-muted text-center my-4">Sem vendas concluídas no período.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-lg-5">
        <div class="card shadow-sm mb-3">
            <div class="card-header fw-semibold">Produtos mais vendidos</div>
            <table class="table table-sm mb-0">
                <tbody>
                <?php foreach ($topProdutos as $t): ?>
                    <tr><td><?= e($t['produto_nome']) ?></td><td class="text-end"><?= (int)$t['qtd'] ?> un.</td><td class="text-end"><?= money($t['total']) ?></td></tr>
                <?php endforeach; ?>
                <?php if (!$topProdutos): ?><tr><td class="text-muted text-center py-3">Sem dados.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
        <div class="card shadow-sm">
            <div class="card-header fw-semibold">Por forma de pagamento</div>
            <table class="table table-sm mb-0">
                <tbody>
                <?php foreach ($porForma as $f): ?>
                    <tr><td><?= e(FormaPagamento::rotulo($f['forma_pagamento'])) ?></td><td class="text-end"><?= (int)$f['qtd'] ?> venda(s)</td><td class="text-end"><?= money($f['total']) ?></td></tr>
                <?php endforeach; ?>
                <?php if (!$porForma): ?><tr><td class="text-muted text-center py-3">Sem dados.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Lista de vendas -->
<div class="card shadow-sm">
    <div class="card-header fw-semibold">Vendas registradas <span class="text-muted fw-normal">(<?= (int)$total ?>)</span></div>
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr><th>#</th><th>Data</th><th>Cliente</th><th>Pagamento</th><th class="text-end">Total</th><th>Status</th><th class="text-end no-print">Ações</th></tr>
            </thead>
            <tbody>
            <?php foreach ($vendas as $v): ?>
                <tr class="<?= $v->concluida() ? '' : 'table-secondary text-muted' ?>">
                    <td><?= (int)$v->id ?></td>
                    <td><?= e(data_br($v->criado_em, true)) ?></td>
                    <td><?= e($v->cliente_nome ?? 'Consumidor final') ?></td>
                    <td><?= e(FormaPagamento::rotulo($v->forma_pagamento)) ?></td>
                    <td class="text-end fw-medium"><?= money($v->total) ?></td>
                    <td><span class="badge text-bg-<?= $v->concluida() ? 'success' : 'secondary' ?>"><?= $v->concluida() ? 'Concluída' : 'Cancelada' ?></span></td>
                    <td class="text-end text-nowrap no-print">
                        <a href="<?= href('relatorios/ver', ['id' => $v->id]) ?>" class="btn btn-outline-primary btn-sm">Ver</a>
                        <?php if ($v->concluida()): ?>
                            <a href="<?= href('relatorios/editar', ['id' => $v->id]) ?>" class="btn btn-warning btn-sm">Editar</a>
                            <form method="POST" action="<?= href('relatorios/cancelar') ?>" class="d-inline"
                                  onsubmit="return confirm('Cancelar a venda #<?= (int)$v->id ?>? Os itens voltam ao estoque.')">
                                <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$v->id ?>">
                                <button class="btn btn-outline-danger btn-sm">Cancelar</button>
                            </form>
                        <?php else: ?>
                            <form method="POST" action="<?= href('relatorios/excluir') ?>" class="d-inline"
                                  onsubmit="return confirm('Excluir definitivamente a venda #<?= (int)$v->id ?>?')">
                                <?= csrf_field() ?><input type="hidden" name="id" value="<?= (int)$v->id ?>">
                                <button class="btn btn-danger btn-sm">Excluir</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$vendas): ?>
                <tr><td colspan="7" class="text-center text-muted py-4">Nenhuma venda encontrada para os filtros informados.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3">
    <?php partial('partials/paginacao', ['route' => 'relatorios/index', 'params' => $params,
        'page' => $page, 'perPage' => $perPage, 'total' => $total]); ?>
</div>

<?php if ($porDia): ?>
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.3/dist/chart.umd.min.js"></script>
<script>
    new Chart(document.getElementById('graficoDias'), {
        type: 'bar',
        data: {
            labels: <?= json_encode($labels, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE) ?>,
            datasets: [{ label: 'Faturamento (R$)', data: <?= json_encode($valores) ?>, backgroundColor: '#198754' }]
        },
        options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
    });
</script>
<?php endif; ?>
