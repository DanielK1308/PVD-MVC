<?php /** @var array $totaisHoje */ ?>
<h1 class="h3 mb-4">Ponto de Venda</h1>

<div class="row g-3 mb-4">
    <div class="col-md-4">
        <div class="card shadow-sm h-100"><div class="card-body">
            <div class="text-muted small">Vendas de hoje</div>
            <div class="fs-3 fw-semibold"><?= (int)($totaisHoje['qtd_concluidas'] ?? 0) ?></div>
        </div></div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm h-100"><div class="card-body">
            <div class="text-muted small">Faturamento de hoje</div>
            <div class="fs-3 fw-semibold"><?= money($totaisHoje['liquido'] ?? 0) ?></div>
        </div></div>
    </div>
    <div class="col-md-4">
        <div class="card shadow-sm h-100"><div class="card-body">
            <div class="text-muted small">Ticket médio de hoje</div>
            <div class="fs-3 fw-semibold"><?= money($totaisHoje['ticket_medio'] ?? 0) ?></div>
        </div></div>
    </div>
</div>

<div class="row g-3">
    <?php
    $atalhos = [
        ['Nova venda',  'Monte o carrinho e finalize a venda.',        'carrinho/index',   'success'],
        ['Clientes',    'Cadastre e gerencie seus clientes.',          'clientes/index',   'primary'],
        ['Produtos',    'Estoque, preços e imagens.',                  'produtos/index',   'primary'],
        ['Relatórios',  'Vendas por período, cliente e pagamento.',    'relatorios/index', 'dark'],
    ];
    foreach ($atalhos as [$nome, $desc, $rota, $cor]): ?>
        <div class="col-md-6 col-lg-3">
            <a href="<?= href($rota) ?>" class="card shadow-sm h-100 text-decoration-none">
                <div class="card-body">
                    <h2 class="h5 text-<?= e($cor) ?>"><?= e($nome) ?></h2>
                    <p class="text-muted mb-0"><?= e($desc) ?></p>
                </div>
            </a>
        </div>
    <?php endforeach; ?>
</div>
