<?php /** @var App\Models\Cliente[] $clientes */ ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <h1 class="h3 mb-0">Clientes <span class="text-muted fs-6">(<?= (int)$total ?>)</span></h1>
    <a href="<?= href('clientes/novo') ?>" class="btn btn-success">+ Novo cliente</a>
</div>

<form method="GET" action="index.php" class="row g-2 mb-3">
    <input type="hidden" name="r" value="clientes/index">
    <div class="col-sm-8 col-md-6">
        <input type="search" name="q" value="<?= e($q) ?>" class="form-control"
               placeholder="Buscar por nome, CPF/CNPJ, e-mail ou telefone">
    </div>
    <div class="col-auto">
        <button class="btn btn-primary">Buscar</button>
        <?php if ($q !== ''): ?><a href="<?= href('clientes/index') ?>" class="btn btn-outline-secondary">Limpar</a><?php endif; ?>
    </div>
</form>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr><th>Nome</th><th>CPF/CNPJ</th><th>Contato</th><th>Cidade/UF</th><th>Status</th><th class="text-end">Ações</th></tr>
            </thead>
            <tbody>
            <?php foreach ($clientes as $c): ?>
                <tr>
                    <td class="fw-medium"><?= e($c->nome) ?></td>
                    <td><?= e(doc_fmt($c->cpf_cnpj)) ?></td>
                    <td>
                        <?= e($c->telefone ?? '—') ?>
                        <?php if ($c->email): ?><div class="small text-muted"><?= e($c->email) ?></div><?php endif; ?>
                    </td>
                    <td><?= e(trim(($c->cidade ?? '') . ($c->uf ? '/' . $c->uf : '')) ?: '—') ?></td>
                    <td><span class="badge text-bg-<?= $c->ativo ? 'success' : 'secondary' ?>"><?= $c->ativo ? 'Ativo' : 'Inativo' ?></span></td>
                    <td class="text-end text-nowrap">
                        <a href="<?= href('clientes/editar', ['id' => $c->id]) ?>" class="btn btn-warning btn-sm">Editar</a>
                        <form method="POST" action="<?= href('clientes/excluir') ?>" class="d-inline"
                              onsubmit="return confirm('Excluir o cliente &quot;<?= e(addslashes($c->nome)) ?>&quot;?')">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= (int)$c->id ?>">
                            <button class="btn btn-danger btn-sm">Excluir</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$clientes): ?>
                <tr><td colspan="6" class="text-center text-muted py-4">Nenhum cliente encontrado.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3">
    <?php partial('partials/paginacao', ['route' => 'clientes/index', 'params' => $q !== '' ? ['q' => $q] : [],
        'page' => $page, 'perPage' => $perPage, 'total' => $total]); ?>
</div>
