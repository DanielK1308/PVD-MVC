<?php /** @var App\Models\Cliente $cliente */ /** @var array $errors */
$editando = $cliente->id !== null;
$campo = function (string $nome, string $rotulo, ?string $valor, string $extra = '', string $col = 'col-md-6', string $type = 'text') use ($errors): void { ?>
    <div class="<?= e($col) ?>">
        <label for="<?= e($nome) ?>" class="form-label"><?= e($rotulo) ?></label>
        <input type="<?= e($type) ?>" id="<?= e($nome) ?>" name="<?= e($nome) ?>" value="<?= e($valor) ?>"
               class="form-control<?= invalid($errors, $nome) ?>" <?= $extra ?>>
        <?= feedback($errors, $nome) ?>
    </div>
<?php }; ?>

<h1 class="h3 mb-3"><?= $editando ? 'Editar cliente' : 'Novo cliente' ?></h1>

<form method="POST" action="<?= href($editando ? 'clientes/atualizar' : 'clientes/salvar') ?>" class="card shadow-sm" novalidate>
    <div class="card-body">
        <?= csrf_field() ?>
        <?php if ($editando): ?><input type="hidden" name="id" value="<?= (int)$cliente->id ?>"><?php endif; ?>

        <div class="row g-3">
            <?php
            $campo('nome', 'Nome / Razão social *', $cliente->nome, 'maxlength="150" required', 'col-md-8');
            $campo('cpf_cnpj', 'CPF / CNPJ', $cliente->cpf_cnpj ? doc_fmt($cliente->cpf_cnpj) : '', 'maxlength="18" inputmode="numeric"', 'col-md-4');
            $campo('email', 'E-mail', $cliente->email, 'maxlength="150"', 'col-md-6', 'email');
            $campo('telefone', 'Telefone', $cliente->telefone, 'maxlength="20"', 'col-md-6', 'tel');
            $campo('cep', 'CEP', $cliente->cep, 'maxlength="9" inputmode="numeric"', 'col-md-3');
            $campo('endereco', 'Endereço', $cliente->endereco, 'maxlength="200"', 'col-md-7');
            $campo('numero', 'Número', $cliente->numero, 'maxlength="20"', 'col-md-2');
            $campo('bairro', 'Bairro', $cliente->bairro, 'maxlength="100"', 'col-md-4');
            $campo('cidade', 'Cidade', $cliente->cidade, 'maxlength="100"', 'col-md-6');
            $campo('uf', 'UF', $cliente->uf, 'maxlength="2" style="text-transform:uppercase"', 'col-md-2');
            ?>
            <div class="col-12">
                <label for="observacoes" class="form-label">Observações</label>
                <textarea id="observacoes" name="observacoes" rows="3" class="form-control"><?= e($cliente->observacoes) ?></textarea>
            </div>
            <div class="col-12">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" role="switch" id="ativo" name="ativo" value="1" <?= $cliente->ativo ? 'checked' : '' ?>>
                    <label class="form-check-label" for="ativo">Cliente ativo (aparece no carrinho de vendas)</label>
                </div>
            </div>
        </div>
    </div>
    <div class="card-footer d-flex justify-content-between">
        <a href="<?= href('clientes/index') ?>" class="btn btn-secondary">Voltar</a>
        <button type="submit" class="btn btn-primary"><?= $editando ? 'Salvar alterações' : 'Cadastrar' ?></button>
    </div>
</form>
