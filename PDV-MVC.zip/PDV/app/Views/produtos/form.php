<?php /** @var App\Models\Produto $produto */ /** @var array $errors */
$editando = $produto->id !== null;
$campo = function (string $nome, string $rotulo, mixed $valor, string $extra = '', string $col = 'col-md-6', string $type = 'text') use ($errors): void { ?>
    <div class="<?= e($col) ?>">
        <label for="<?= e($nome) ?>" class="form-label"><?= e($rotulo) ?></label>
        <input type="<?= e($type) ?>" id="<?= e($nome) ?>" name="<?= e($nome) ?>" value="<?= e($valor) ?>"
               class="form-control<?= invalid($errors, $nome) ?>" <?= $extra ?>>
        <?= feedback($errors, $nome) ?>
    </div>
<?php }; ?>

<h1 class="h3 mb-3"><?= $editando ? 'Editar produto' : 'Novo produto' ?></h1>

<form method="POST" action="<?= href($editando ? 'produtos/atualizar' : 'produtos/salvar') ?>"
      enctype="multipart/form-data" class="card shadow-sm" novalidate>
    <div class="card-body">
        <?= csrf_field() ?>
        <?php if ($editando): ?><input type="hidden" name="id" value="<?= (int)$produto->id ?>"><?php endif; ?>

        <div class="row g-3">
            <?php
            $campo('cod', 'Código *', $produto->cod, 'maxlength="50" required', 'col-md-4');
            $campo('nome', 'Nome *', $produto->nome, 'maxlength="150" required', 'col-md-8');
            $campo('categoria', 'Categoria', $produto->categoria, 'maxlength="100"', 'col-md-4');
            $campo('validade', 'Validade', $produto->validade, '', 'col-md-4', 'date');
            $campo('quantidade', 'Quantidade em estoque *', $produto->quantidade, 'min="0" step="1" required', 'col-md-4', 'number');
            $campo('preco_unitario', 'Preço unitário (R$) *', number_format($produto->preco_unitario, 2, '.', ''), 'min="0" step="0.01" required', 'col-md-6', 'number');
            $campo('preco_pacote', 'Preço do pacote (R$)', number_format($produto->preco_pacote, 2, '.', ''), 'min="0" step="0.01"', 'col-md-6', 'number');
            ?>
            <div class="col-12">
                <label for="imagem" class="form-label">Imagem do produto <?= $editando ? '(deixe em branco para manter a atual)' : '' ?></label>
                <div class="d-flex align-items-center gap-3">
                    <?php if ($produto->imagem): ?>
                        <img class="thumb" src="imagens/<?= e(rawurlencode($produto->imagem)) ?>" alt="">
                    <?php endif; ?>
                    <input type="file" id="imagem" name="imagem" accept="image/*" class="form-control<?= invalid($errors, 'imagem') ?>">
                    <?= feedback($errors, 'imagem') ?>
                </div>
            </div>
        </div>
    </div>
    <div class="card-footer d-flex justify-content-between">
        <a href="<?= href('produtos/index') ?>" class="btn btn-secondary">Voltar</a>
        <button type="submit" class="btn btn-primary"><?= $editando ? 'Salvar alterações' : 'Cadastrar' ?></button>
    </div>
</form>
