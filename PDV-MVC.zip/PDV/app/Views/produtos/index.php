<?php /** @var App\Models\Produto[] $produtos */ ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <h1 class="h3 mb-0">Produtos <span class="text-muted fs-6">(<?= (int)$total ?>)</span></h1>
    <a href="<?= href('produtos/novo') ?>" class="btn btn-success">+ Novo produto</a>
</div>

<form method="GET" action="index.php" class="row g-2 mb-3">
    <input type="hidden" name="r" value="produtos/index">
    <div class="col-sm-8 col-md-6">
        <input type="search" name="q" value="<?= e($q) ?>" class="form-control" placeholder="Buscar por nome, código ou categoria">
    </div>
    <div class="col-auto">
        <button class="btn btn-primary">Buscar</button>
        <?php if ($q !== ''): ?><a href="<?= href('produtos/index') ?>" class="btn btn-outline-secondary">Limpar</a><?php endif; ?>
    </div>
</form>

<div class="card shadow-sm">
    <div class="table-responsive">
        <table class="table table-hover align-middle mb-0">
            <thead class="table-light">
                <tr><th></th><th>Cód.</th><th>Nome</th><th>Categoria</th><th>Validade</th><th class="text-end">Estoque</th><th class="text-end">Preço</th><th class="text-end">Ações</th></tr>
            </thead>
            <tbody>
            <?php foreach ($produtos as $p): ?>
                <tr>
                    <td><?php if ($p->imagem): ?><img class="thumb" src="imagens/<?= e(rawurlencode($p->imagem)) ?>" alt=""><?php else: ?><div class="thumb"></div><?php endif; ?></td>
                    <td><?= e($p->cod) ?></td>
                    <td class="fw-medium"><?= e($p->nome) ?></td>
                    <td><?= e($p->categoria ?? '—') ?></td>
                    <td><?= e(data_br($p->validade)) ?></td>
                    <td class="text-end"><span class="badge text-bg-<?= $p->quantidade > 0 ? 'secondary' : 'danger' ?>"><?= (int)$p->quantidade ?></span></td>
                    <td class="text-end"><?= money($p->preco_unitario) ?></td>
                    <td class="text-end text-nowrap">
                        <a href="<?= href('produtos/editar', ['id' => $p->id]) ?>" class="btn btn-warning btn-sm">Editar</a>
                        <form method="POST" action="<?= href('produtos/excluir') ?>" class="d-inline"
                              onsubmit="return confirm('Excluir o produto &quot;<?= e(addslashes($p->nome)) ?>&quot;? Vendas antigas são mantidas.')">
                            <?= csrf_field() ?>
                            <input type="hidden" name="id" value="<?= (int)$p->id ?>">
                            <button class="btn btn-danger btn-sm">Excluir</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
            <?php if (!$produtos): ?>
                <tr><td colspan="8" class="text-center text-muted py-4">Nenhum produto encontrado.</td></tr>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<div class="mt-3">
    <?php partial('partials/paginacao', ['route' => 'produtos/index', 'params' => $q !== '' ? ['q' => $q] : [],
        'page' => $page, 'perPage' => $perPage, 'total' => $total]); ?>
</div>
