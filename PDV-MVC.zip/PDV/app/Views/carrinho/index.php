<?php
use App\Models\FormaPagamento;
/**
 * @var string $q
 * @var App\Models\Produto[] $produtos
 * @var array $resumo
 * @var array $config
 * @var App\Models\Cliente[] $clientes
 */
$itens = $resumo['itens'];
?>
<h1 class="h3 mb-3">Carrinho de vendas</h1>

<div class="row g-4">
    <!-- ========== Catálogo ========== -->
    <div class="col-lg-6">
        <div class="card shadow-sm">
            <div class="card-header fw-semibold">1. Buscar produtos</div>
            <div class="card-body">
                <form method="GET" action="index.php" class="input-group mb-3">
                    <input type="hidden" name="r" value="carrinho/index">
                    <input type="search" name="q" value="<?= e($q) ?>" class="form-control" placeholder="Nome ou código do produto" autofocus>
                    <button class="btn btn-primary">Buscar</button>
                </form>

                <div class="table-responsive">
                    <table class="table table-sm align-middle mb-0">
                        <thead><tr><th></th><th>Produto</th><th class="text-end">Preço</th><th class="text-end">Estoque</th><th></th></tr></thead>
                        <tbody>
                        <?php foreach ($produtos as $p): ?>
                            <tr>
                                <td><?php if ($p->imagem): ?><img class="thumb" src="imagens/<?= e(rawurlencode($p->imagem)) ?>" alt=""><?php else: ?><div class="thumb"></div><?php endif; ?></td>
                                <td><div class="fw-medium"><?= e($p->nome) ?></div><div class="small text-muted"><?= e($p->cod) ?></div></td>
                                <td class="text-end"><?= money($p->preco_unitario) ?></td>
                                <td class="text-end"><?= (int)$p->quantidade ?></td>
                                <td class="text-end">
                                    <?php if ($p->quantidade > 0): ?>
                                    <form method="POST" action="<?= href('carrinho/adicionar') ?>" class="d-flex gap-1 justify-content-end">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="produto_id" value="<?= (int)$p->id ?>">
                                        <input type="hidden" name="q" value="<?= e($q) ?>">
                                        <input type="number" name="quantidade" value="1" min="1" max="<?= (int)$p->quantidade ?>"
                                               class="form-control form-control-sm" style="width:70px" aria-label="Quantidade">
                                        <button class="btn btn-success btn-sm">Adicionar</button>
                                    </form>
                                    <?php else: ?>
                                        <span class="badge text-bg-danger">Sem estoque</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (!$produtos): ?>
                            <tr><td colspan="5" class="text-center text-muted py-3">Nenhum produto encontrado.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- ========== Carrinho ========== -->
    <div class="col-lg-6">
        <div class="card shadow-sm">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span class="fw-semibold">2. Carrinho (<?= (int)$resumo['qtd_itens'] ?> <?= $resumo['qtd_itens'] === 1 ? 'item' : 'itens' ?>)</span>
                <?php if ($itens): ?>
                <form method="POST" action="<?= href('carrinho/limpar') ?>" onsubmit="return confirm('Esvaziar o carrinho?')">
                    <?= csrf_field() ?>
                    <input type="hidden" name="q" value="<?= e($q) ?>">
                    <button class="btn btn-outline-danger btn-sm">Esvaziar</button>
                </form>
                <?php endif; ?>
            </div>

            <?php if (!$itens): ?>
                <div class="card-body text-center text-muted py-5">O carrinho está vazio. Adicione produtos ao lado.</div>
            <?php else: ?>
                <div class="table-responsive">
                    <table class="table table-sm align-middle mb-0">
                        <thead><tr><th>Produto</th><th class="text-end">Unit.</th><th style="width:130px">Qtd</th><th class="text-end">Subtotal</th><th></th></tr></thead>
                        <tbody>
                        <?php foreach ($itens as $i): ?>
                            <tr>
                                <td><div class="fw-medium"><?= e($i->produto_nome) ?></div><div class="small text-muted"><?= e($i->produto_cod) ?></div></td>
                                <td class="text-end"><?= money($i->preco_unitario) ?></td>
                                <td>
                                    <form method="POST" action="<?= href('carrinho/atualizar') ?>" class="d-flex gap-1">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="produto_id" value="<?= (int)$i->produto_id ?>">
                                        <input type="hidden" name="q" value="<?= e($q) ?>">
                                        <input type="number" name="quantidade" value="<?= (int)$i->quantidade ?>" min="0" max="<?= (int)$i->estoque ?>"
                                               class="form-control form-control-sm" aria-label="Quantidade">
                                        <button class="btn btn-outline-primary btn-sm" title="Atualizar quantidade">OK</button>
                                    </form>
                                </td>
                                <td class="text-end"><?= money($i->subtotal) ?></td>
                                <td class="text-end">
                                    <form method="POST" action="<?= href('carrinho/remover') ?>">
                                        <?= csrf_field() ?>
                                        <input type="hidden" name="produto_id" value="<?= (int)$i->produto_id ?>">
                                        <input type="hidden" name="q" value="<?= e($q) ?>">
                                        <button class="btn btn-outline-danger btn-sm" title="Remover item">&times;</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Fechamento -->
                <form method="POST" action="<?= href('carrinho/finalizar') ?>" class="card-body border-top">
                    <?= csrf_field() ?>
                    <input type="hidden" name="q" value="<?= e($q) ?>">
                    <div class="row g-2">
                        <div class="col-12">
                            <label class="form-label mb-1" for="cliente_id">Cliente</label>
                            <select name="cliente_id" id="cliente_id" class="form-select">
                                <option value="0">Consumidor final</option>
                                <?php foreach ($clientes as $c): ?>
                                    <option value="<?= (int)$c->id ?>" <?= (int)$config['cliente_id'] === $c->id ? 'selected' : '' ?>>
                                        <?= e($c->nome) ?><?= $c->cpf_cnpj ? ' — ' . e(doc_fmt($c->cpf_cnpj)) : '' ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-sm-6">
                            <label class="form-label mb-1" for="desconto_tipo">Desconto</label>
                            <select name="desconto_tipo" id="desconto_tipo" class="form-select">
                                <option value="nenhum"     <?= $config['desconto_tipo'] === 'nenhum' ? 'selected' : '' ?>>Sem desconto</option>
                                <option value="percentual" <?= $config['desconto_tipo'] === 'percentual' ? 'selected' : '' ?>>Percentual (%)</option>
                                <option value="valor"      <?= $config['desconto_tipo'] === 'valor' ? 'selected' : '' ?>>Valor fixo (R$)</option>
                            </select>
                        </div>
                        <div class="col-sm-6">
                            <label class="form-label mb-1" for="desconto_valor">Valor do desconto</label>
                            <input type="number" name="desconto_valor" id="desconto_valor" min="0" step="0.01"
                                   value="<?= e(number_format((float)$config['desconto_valor'], 2, '.', '')) ?>" class="form-control">
                        </div>
                        <div class="col-12">
                            <label class="form-label mb-1" for="forma_pagamento">Forma de pagamento</label>
                            <select name="forma_pagamento" id="forma_pagamento" class="form-select">
                                <?php foreach (FormaPagamento::LISTA as $cod => $rotulo): ?>
                                    <option value="<?= e($cod) ?>" <?= $config['forma_pagamento'] === $cod ? 'selected' : '' ?>><?= e($rotulo) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-12">
                            <label class="form-label mb-1" for="observacoes">Observações</label>
                            <textarea name="observacoes" id="observacoes" rows="2" maxlength="500" class="form-control"><?= e($config['observacoes']) ?></textarea>
                        </div>
                    </div>

                    <dl class="row mt-3 mb-2">
                        <dt class="col-6 fw-normal text-muted">Subtotal</dt><dd class="col-6 text-end mb-1"><?= money($resumo['subtotal']) ?></dd>
                        <dt class="col-6 fw-normal text-muted">Desconto</dt><dd class="col-6 text-end mb-1 text-danger">− <?= money($resumo['desconto']) ?></dd>
                        <dt class="col-6 fs-5">Total</dt><dd class="col-6 text-end fs-4 fw-bold mb-0"><?= money($resumo['total']) ?></dd>
                    </dl>

                    <div class="d-grid gap-2 d-sm-flex justify-content-sm-end">
                        <button type="submit" formaction="<?= href('carrinho/resumo') ?>" class="btn btn-outline-secondary">Aplicar desconto</button>
                        <button type="submit" class="btn btn-success btn-lg">Finalizar venda</button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>
