<?php
use App\Core\Session;
$flashes = Session::pullFlash();
$rota    = rota_atual();
$nav     = [
    'home'       => ['Início', 'home/index'],
    'clientes'   => ['Clientes', 'clientes/index'],
    'produtos'   => ['Produtos', 'produtos/index'],
    'carrinho'   => ['Carrinho', 'carrinho/index'],
    'relatorios' => ['Relatórios', 'relatorios/index'],
];
$qtdCarrinho = carrinho_qtd();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e($titulo ?? 'PDV') ?> · PDV</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        .thumb { width: 44px; height: 44px; object-fit: cover; border-radius: 6px; background: #e9ecef; }
        @media print { .no-print { display: none !important; } }
    </style>
</head>
<body class="bg-light">
<nav class="navbar navbar-expand-lg navbar-dark bg-dark no-print">
    <div class="container">
        <a class="navbar-brand fw-semibold" href="<?= href('home/index') ?>">PDV</a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#menu">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="menu">
            <ul class="navbar-nav me-auto">
                <?php foreach ($nav as $chave => [$rotulo, $destino]): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= $rota === $chave ? 'active' : '' ?>" href="<?= href($destino) ?>">
                            <?= e($rotulo) ?>
                            <?php if ($chave === 'carrinho' && $qtdCarrinho > 0): ?>
                                <span class="badge text-bg-success"><?= (int)$qtdCarrinho ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
</nav>

<main class="container py-4">
    <?php foreach ($flashes as $f): ?>
        <div class="alert alert-<?= e($f['type']) ?> alert-dismissible fade show no-print" role="alert">
            <?= e($f['message']) ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
    <?php endforeach; ?>

    <?= $content ?>
</main>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
