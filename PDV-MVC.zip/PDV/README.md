# PDV — MVC + Design Patterns (PHP 8 + PostgreSQL/Neon)

Refatoração do PDV original (scripts soltos com SQL dentro do HTML) para uma
arquitetura **MVC**, com os CRUDs de **Clientes**, **Carrinho de Vendas** e
**Relatórios de Vendas**. O CRUD de **Produtos** também foi migrado para MVC.

## Como instalar

1. **Banco**: rode `database/schema.sql` no SQL Editor do Neon
   (é idempotente; não mexe na tabela `produtos` se ela já existir).
2. **Conexão**: copie `.env.example` para `.env` e preencha `SRVDB` com a string do Neon
   (o mesmo formato que você já usava).
3. **Pasta `imagens/`** precisa ter permissão de escrita (uploads de produtos).
4. Acesse `index.php`. Para testar local: `php -S localhost:8000` na raiz do projeto.

Requisitos: PHP **8.0+** com `pdo_pgsql`, `mbstring` e `fileinfo/gd` (para `getimagesize`).

## Estrutura

```
index.php                  Front Controller (único ponto de entrada + DI + rotas)
app/
  bootstrap.php            autoload PSR-4, .env, fuso America/Cuiaba, sessão
  Core/                    Router, Container (DI), Database (Singleton), View, Session,
                           Csrf, Validator, Controller base, helpers
  Models/                  Cliente, Produto, Venda, ItemVenda, FormaPagamento (entidades)
  Repositories/            Contracts/*Interface + Pdo*Repository (todo o SQL fica aqui)
  Services/                CarrinhoService, VendaService (regras de negócio + transação)
  Strategies/              Descontos (Strategy + Factory)
  Controllers/             Home, Cliente, Produto, Carrinho, Relatorio
  Views/                   layouts/, partials/, home/, clientes/, produtos/, carrinho/, relatorios/
database/schema.sql        tabelas: produtos, clientes, vendas, itens_venda
imagens/                   uploads dos produtos
```

## Design patterns aplicados

| Pattern | Onde | Por quê |
|---|---|---|
| **MVC** | `Models` / `Views` / `Controllers` | separa dados, tela e fluxo |
| **Front Controller + Router** | `index.php`, `Core/Router` | todas as requisições passam por um só lugar |
| **Singleton** | `Core/Database` | uma única conexão PDO por requisição |
| **Repository** (+ interfaces) | `Repositories/` | controllers não conhecem SQL; dá para trocar o banco implementando a interface |
| **Dependency Injection** | `Core/Container` (autowiring) | classes recebem dependências pelo construtor |
| **Service Layer** | `CarrinhoService`, `VendaService` | regras que envolvem várias tabelas e transações |
| **Strategy** | `Strategies/Desconto*` | sem desconto / percentual / valor fixo, intercambiáveis |
| **Factory** | `DescontoFactory` | escolhe a Strategy a partir do formulário |
| **Template View** | `Views/layouts`, `partials` | layout único reaproveitado |

## CRUDs e rotas (`index.php?r=controller/acao`)

**Clientes** — `clientes/index` (lista + busca + paginação), `novo`, `salvar`, `editar`, `atualizar`, `excluir`.
Valida CPF/CNPJ (dígitos verificadores), e-mail, UF e CEP; impede CPF/CNPJ duplicado.
Cliente com vendas não pode ser excluído: o sistema orienta a **inativá-lo**.

**Carrinho de vendas** — `carrinho/index` (R), `adicionar` (C), `atualizar` quantidade (U),
`remover` / `limpar` (D), `resumo` (cliente, desconto, pagamento), `finalizar`.
O carrinho guarda só `produto_id => quantidade` na sessão; **preço e estoque são sempre lidos do banco**.
Ao finalizar, em uma transação: trava as linhas dos produtos (`FOR UPDATE`), confere o estoque,
grava venda + itens e baixa o estoque.

**Relatórios de vendas** — `relatorios/index` (filtros por período, cliente, pagamento e status;
indicadores, gráfico por dia, ranking de produtos, totais por pagamento), `ver` (comprovante/impressão),
`editar` + `atualizar` (cliente, pagamento, observações), `cancelar` (devolve estoque),
`excluir` (somente vendas canceladas), `exportar` (CSV para Excel).

## Segurança incluída

- Prepared statements em 100% das queries (o `salvar_produto` MySQL antigo concatenava SQL).
- Token **CSRF** em todo formulário POST; exclusões nunca por GET.
- Escape de saída (`e()`) em todas as views.
- Upload de imagem validado (extensão, `getimagesize`, 2 MB) com nome aleatório; `imagens/` não executa PHP.
- `.htaccess` bloqueia `.env`, `app/` e `database/`.

## Observações

- Preços usam `NUMERIC(12,2)` no banco e `round(..., 2)` no PHP.
- O campo **Preço pacote** continua no cadastro de produtos, mas a venda usa o **preço unitário**.
- O fuso `America/Cuiaba` é aplicado no PHP e nas consultas de relatório (não depende do `SET TIME ZONE` do pooler).
